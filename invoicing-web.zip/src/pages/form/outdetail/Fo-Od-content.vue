<template>
  <div class="bodyRight">
    <form class="outdetail-form">
      <fieldset>
        <legend>报表中心-出库明细表</legend>
        <div>
          <a href="#" download="purchorderReport">
            <el-button class = "button" size="medium"  round>出库明细表</el-button>
          </a>
        </div>
      </fieldset>
    </form>
  </div>
</template>

<script>
  export default {
    name:'Content'
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
  }
  .outdetail-form{
    width: 80%;
    height: 82%;
    margin-left: 18.4%;
  }
  fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
</style>
