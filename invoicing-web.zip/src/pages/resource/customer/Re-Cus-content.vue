<template>
  <div class="bodyRight">
    <form class="form form-horizontal">
      <fieldset class="fieldset">
        <legend>资源管理-客户商管理</legend>
        <div style="height: 90%;overflow-y: auto">
        <!--条件筛选框-->
        <el-collapse style="width:98%;margin-top: 1.5%" v-model="activeNames">
          <el-collapse-item title="筛选条件：客户地址 / 负责人" name="1">
            <span>筛选地址：</span>
            <el-cascader
              placeholder="请选择地址"
              size="mini"
              v-model="addr1"
              :options="options"
              :props="{ expandTrigger: 'hover' }">
            </el-cascader>
            <el-input style="width: 20%" v-model="addr2" size="mini" placeholder="请输入详细地址"></el-input>
            <div class="block" style="margin-top: 1%">
              <span>筛选负责人：</span>
              <el-select size="mini" v-model="sale" placeholder="请选择负责人">
                <el-option
                  v-for="item in options2"
                  :key="item.value"
                  :label="item.label"
                  :value="item.label">
                </el-option>
              </el-select>
            </div>
          </el-collapse-item>
        </el-collapse>

        <!--按钮+搜索-->
        <div class="btndiv">
          <button class="btn-delete" type="button" @click="Delete" ><i class="iconfont  iconshanchu">批量删除</i></button>
          <button class="btn-add" type="button" @click="showaddDialog" ><i class="iconfont icontianjia1">添加职务</i></button>
          <div class=" demo-input-size" style="float: right;width: 38%">
            <el-input
              placeholder="请输入客户商名称"
              v-model="cusname"
              style="width: 43.5%">
            </el-input>
            <el-input
              placeholder="请输入接洽人名称"
              v-model="conname"
              style="width: 43.5%">
            </el-input>
            <el-button icon="el-icon-search" @click="Search(addr1,addr2,sale,cusname,conname)" circle></el-button>
          </div>
        </div>

        <!--表格-->
        <div style="height:100%">
          <el-table :data="list" border style="width: 98%;" :max-height="330">
            <el-table-column fixed style="height:60%" width="35">
              <template slot-scope="scope">
                <el-checkbox @change="Check(scope.row.cId)"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column fixed prop="cId" label="客户商编号" width="150"></el-table-column>
            <el-table-column fixed prop="cName" label="客户商名称" width="120"></el-table-column>
            <el-table-column prop="cAreaid" label="客户商区域编码" width="120"></el-table-column>
            <el-table-column prop="cAddr" label="地址" width="300"></el-table-column>
            <el-table-column prop="cTele" label="电话" width="120"></el-table-column>
            <el-table-column prop="cFax" label="传真" width="120"></el-table-column>
            <el-table-column prop="cZip" label="邮编" width="120"></el-table-column>
            <el-table-column prop="cGcode" label="企业法人代码" width="120"></el-table-column>
            <el-table-column prop="cCorporation" label="企业法人名称" width="120"></el-table-column>
            <el-table-column prop="cContacter" label="接洽人名称" width="100"></el-table-column>
            <el-table-column prop="cMphone" label="接洽人电话" width="120"></el-table-column>
            <el-table-column prop="cSale" label="我方业务员" width="100"></el-table-column>
            <el-table-column prop="iStatus" :formatter="statusFormat" label="状态" width="100"></el-table-column>
            <el-table-column fixed="right" label="操作" width="130">
              <!-- 查看的框 -->
              <template slot-scope="scope">
                <el-popover
                  placement="right"
                  width="500"
                  trigger="click">
                  <el-form>
                    <el-form-item>
                      <span style="font-weight: bold">客户商编号：</span>
                      <span>{{scope.row.cId}}</span>
                      <span style="margin-left: 9%;font-weight: bold">客户商名称：</span>
                      <span>{{scope.row.cName}}</span>
                    </el-form-item>
                    <el-form-item>
                      <span style="font-weight: bold">区域编码：</span>
                      <span>{{scope.row.cAreaid}}</span>
                      <span  style="margin-left: 9%;font-weight: bold">地址：</span>
                      <span>{{scope.row.cAddr}}</span>
                    </el-form-item>
                    <el-form-item>
                      <span style="font-weight: bold">电话：</span>
                      <span>{{scope.row.cTele}}</span>
                      <span  style="margin-left: 9%;font-weight: bold">传真：</span>
                      <span>{{scope.row.cFax}}</span>
                      <span  style="margin-left: 9%;font-weight: bold">邮编：</span>
                      <span>{{scope.row.cZip}}</span>
                    </el-form-item>
                    <el-form-item>
                      <span style="font-weight: bold">企业法人代码：</span>
                      <span>{{scope.row.cGcode}}</span>
                      <span  style="margin-left: 9%;font-weight: bold">企业法人人名称：</span>
                      <span>{{scope.row.cCorporation}}</span>
                    </el-form-item>
                    <el-form-item>
                      <span style="font-weight: bold">接洽人名称：</span>
                      <span>{{scope.row.cContacter}}</span>
                      <span  style="margin-left: 9%;font-weight: bold">接洽人电话：</span>
                      <span>{{scope.row.cMphone}}</span>
                    </el-form-item>
                    <el-form-item>
                      <span style="font-weight: bold">我方业务员：</span>
                      <span>{{scope.row.cSale}}</span>
                      <span  style="margin-left: 9%;font-weight: bold">客户商状态：</span>
                      <span>{{scope.row.iStatus}}(0为正常，1为停用)</span>
                    </el-form-item>
                  </el-form>
                  <el-button slot="reference" type="text" size="small" >查看</el-button>
                </el-popover>
                <!-- 其他操作 -->
              <el-button style="margin-left: 9%;" type="text" size="small" @click="showDialog(scope.row)">编辑</el-button>
<!--              <el-button type="text" size="small">删除</el-button>-->
              </template>
            </el-table-column>
          </el-table>

          <!--分页-->
          <div class="block">
            <el-pagination
              style="text-align: center;margin-top: 1%"
              @current-change="handleCurrentChange"
              :current-page.sync="currentPage"
              :page-size="size"
              :total="count">
            </el-pagination>
          </div>

        </div>

        <!-- 编辑的模态框 -->
        <el-dialog title="编辑客户商信息" :visible.sync="dialogFormVisible">
          <el-form :model="cusMsg">
            <el-form-item size="mini" label="客户商编码" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cId" autocomplete="off" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item size="mini" label="客户商名称" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cName" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="客户商区域编码" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cAreaid" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="地址" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cAddr" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="电话" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cTele" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="传真" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cFax" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="邮编" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cZip" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="企业法人代码" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cGcode" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="企业法人名称" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cCorporation" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="接洽人名称" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cContacter" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="接洽人电话" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cMphone" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="我方业务员" :label-width="formLabelWidth">
              <el-input v-model="cusMsg.cSale" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="状态" :label-width="formLabelWidth">
<!--              <el-input v-model="cusMsg.iStatus" autocomplete="off" ></el-input>-->
              <el-radio v-model="cusMsg.iStatus" label="0">正常</el-radio>
              <el-radio v-model="cusMsg.iStatus" label="1">停用</el-radio>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="changeData(cusMsg)">确 定</el-button>
          </div>
        </el-dialog>

        <!-- 添加的模态框 -->
        <el-dialog title="添加客户商信息" :visible.sync="dialogAddFormVisible">
          <el-form :model="addcusMsg">
            <el-form-item size="mini" label="客户商编码" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cId" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="客户商名称" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cName" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item size="mini" label="客户商区域编码" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cAreaid" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="地址" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cAddr" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="电话" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cTele" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="传真" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cFax" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="邮编" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cZip" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="企业法人代码" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cGcode" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="企业法人名称" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cCorporation" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="接洽人名称" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cContacter" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="接洽人电话" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cMphone" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="我方业务员" :label-width="formLabelWidth">
              <el-input v-model="addcusMsg.cSale" autocomplete="off" ></el-input>
            </el-form-item>
            <el-form-item size="mini" label="状态" :label-width="formLabelWidth">
              <!--              <el-input v-model="cusMsg.iStatus" autocomplete="off" ></el-input>-->
              <el-radio v-model="addcusMsg.iStatus" label="0">正常</el-radio>
              <el-radio v-model="addcusMsg.iStatus" label="1">停用</el-radio>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogAddFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="AddcusMsg(addcusMsg)">确 定</el-button>
          </div>
        </el-dialog>

        </div>
      </fieldset>
    </form>
  </div>
</template>

<script>
  export default {
    name:'Content',
    props:['list','count','size'],
    data:function(){
      return{
        // sizes:this.size, //一页展示的条数
        // counts:this.count, //总条数
        currentPage:1, //当前页
        collapseChange:false, //折叠面板是否展开
        formLabelWidth:'120px', //表单Label宽度
        dialogFormVisible:false, //编辑表单是否可见
        dialogAddFormVisible:false,//添加表单是否可见
        checkedCustomer:[], //批量删除列表
        flag:false,
        cusMsg:{  //存储当前正在编辑的客户信息
          cId:'',
          cName:'',
          cAreaid:'',
          cAddr:'',
          cTele:'',
          cFax:'',
          cZip:'',
          cGcode:'',
          cCorporation:'',
          cContacter:'',
          cMphone:'',
          cSale:'',
          iStatus:''
        },
        addcusMsg:{  //存储当前正在添加的客户信息
          cId:'',
          cName:'',
          cAreaid:'',
          cAddr:'',
          cTele:'',
          cFax:'',
          cZip:'',
          cGcode:'',
          cCorporation:'',
          cContacter:'',
          cMphone:'',
          cSale:'',
          iStatus:'0'
        },
        addr1:'', //常规地址
        addr2:'', //详细地址
        sale:'', //负责人
        cusname:'', //客户商名称
        conname:'', //接洽人名称
        select:'',
        activeNames:'',
        name:'',
        options: [{
          value: 'anhui',
          label: '安徽省',
          children: [{
            value: 'hefei',
            label: '合肥市',
            children: [{
              value: 'shushan',
              label: '蜀山区'
            }]
          }, {
            value: 'luan',
            label: '六安市',
            children: [{
              value: 'cexiangdaohang',
              label: '侧向导航'
            }]
          }]
        }, {
          value: 'guangdong',
          label: '广东省',
          children: [{
            value: 'guangzhou',
            label: '广州市',
            children: [{
              value: 'nansha',
              label: '南沙区'
            }]
          }]
        }],
        options2:[{
          value: '选项1',
          label: '韩梦圆'
        }, {
          value: '选项2',
          label: '夏金龙'
        }, {
          value: '选项3',
          label: '胡承进'
        }]
      }
    },
    methods:{
      handleCurrentChange(val){
        this.$emit("getCurrentPage",val)
      },
      //弹出添加框
      showaddDialog(){
        this.dialogAddFormVisible = true
      },
      //弹出编辑框
      showDialog(msg){
        this.dialogFormVisible = true
        this.cusMsg.cId = msg.cId
        this.cusMsg.cName = msg.cName
        this.cusMsg.cAreaid = msg.cAreaid
        this.cusMsg.cAddr = msg.cAddr
        this.cusMsg.cTele = msg.cTele
        this.cusMsg.cFax = msg.cFax
        this.cusMsg.cZip = msg.cZip
        this.cusMsg.cGcode = msg.cGcode
        this.cusMsg.cCorporation = msg.cCorporation
        this.cusMsg.cContacter = msg.cContacter
        this.cusMsg.cMphone = msg.cMphone
        this.cusMsg.cSale = msg.cSale
        if(msg.iStatus==0){
          this.cusMsg.iStatus = '0'
        }else if(msg.iStatus==1){
          this.cusMsg.iStatus = '1'
        }
      },
      //显示状态的值
      statusFormat(row,column){
        switch(row.iStatus){
          case 0:
            return '正常';
            break;

          case 1:
            return '停用';
            break;
          default:
            return '未知'
        }
      },
      //编辑
      changeData(cusMsg){
        this.dialogFormVisible = false
        // alert(this.form.cClass+this.form.cDesc+this.form.iIdx)
        this.$emit("submitChange",cusMsg)
      },
      //添加
      AddcusMsg(msgList){
        // alert(msgList.cId+msgList.constructor)
        this.dialogAddFormVisible = false
        this.$emit("addCus",msgList)
        this.addcusMsg.cId = ''
        this.addcusMsg.cName = ''
        this.addcusMsg.cAreaid = ''
        this.addcusMsg.cAddr = ''
        this.addcusMsg.cTele = ''
        this.addcusMsg.cFax = ''
        this.addcusMsg.cZip = ''
        this.addcusMsg.cGcode = ''
        this.addcusMsg.cCorporation = ''
        this.addcusMsg.cContacter = ''
        this.addcusMsg.cMphone = ''
        this.addcusMsg.cSale = ''
        this.addcusMsg.iStatus = '0'
      },

      handleShowRow(msg) {
        console.log(msg);
      },
      //判断是否在数组中
      isInList(val){
        let i = 0
        if(this.checkedCustomer.length!=0) {
          for (i; i < this.checkedCustomer.length; i++){
            if(this.checkedCustomer[i] == val){
              this.flag=true
              break
            }
          }
        }else{
          this.flag=false
        }
        return {con:this.flag,index:i}
      },
      //是否删除
      Check(val){
        // console.log(val)
        this.flag=false
        let con = this.isInList(val).con //判断数组里是否有相同的元素，有则true，无则false
        // console.log(con)
        if(con==false) {
          this.checkedCustomer.push(val) //加入数组
        }else if(con==true) {
          let kindex = this.isInList(val).index //判断数组里相同元素的下标
          console.log(kindex)
          this.checkedCustomer.splice(kindex,1) //从数组中删除
        }
        console.log(this.checkedCustomer)
      },
      //删除
      Delete(){
        this.$emit("delete",this.checkedCustomer)
        this.checkedCustomer = []
      },
      //搜索
      Search(addr1,addr2,sale,cusname,conname){
        let addr = addr1+addr2
        this.$emit('search',addr,sale,cusname,conname)
        this.addr1=''
        this.addr2=''
        this.sale=''
        this.cusname=''
        this.conname=''
      }
    }
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
    padding-top: 1%;
  }
  i{
    font-size: 1em;
  }
  .form{
    width:80%;
    height: 83%;
    margin-left: 18.4%;
  }
  .fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .search-div{
    /*border-bottom: #E6E6E6 solid 1px;*/
    width:98%;
    padding-bottom: 1.5%;
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:13%;
    width:98%;
    border-bottom: #E6E6E6 solid 1px;
    padding-bottom: 1.2%;
    float: left;
  }
  .btn-add{
    background-color: #1E9FFF;
    border: #1E9FFF solid 1px;
    border-radius:2px;
    height: 90%;
    width: 10%;
  }
  .btn-add:hover{
    background-color: #3EACFE;
    border: #3EACFE solid 1px;
  }
  .btn-delete{
    background-color: #FF5722;
    border: #FF5722 solid 1px;
    border-radius:2px;
    width: 10%;
    height:90%;
  }
  .btn-delete:hover,.btn-submit:hover{
    background-color: #FD7449;
    border: #FD7449 solid 1px;
  }

</style>
