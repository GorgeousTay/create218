<template>
  <div class="com">
    <home-header :sid="sid"></home-header>
    <body-left :sid="sid"></body-left>
    <body-right
      :list="goodsList"
      :count="count"
      :size="size"
      :priceList="goodsPrice"
      :count2="count2"
    @submitChange="Update"
    @addMsg="AddMsg"
    @search="Search"
    @getCurrentPage="getPage"
      @delete="Delete"
    @getPrice="getPrice">
    </body-right>
    <home-bottom></home-bottom>
  </div>
</template>

<script>
  import HomeHeader from '@/pages/home/components/Header'
  import BodyLeft from '@/pages/home/components/BodyLeft'
  import Content from './commodity/Re-Com-content'
  import HomeBottom from '@/pages/home/components/Bottom'
  import axios from 'axios'
  export default {
    name:'Commodity',
    components: {
      HomeHeader: HomeHeader,
      BodyLeft: BodyLeft,
      BodyRight: Content,
      HomeBottom: HomeBottom
    },
    data:function(){
      return{
        sid:3,
        page:1,//初始页数是第一页
        size:10,//每页显示10条
        count:0,//获取的总条数
        goodsList:[],
        goodsPrice:[],
        count2:0,
        name:'',
        brand:'',
        gclass:'',
        comp:''
      }
    },
    created(){
      this.sid = this.$route.query.sid;
    },
    mounted(){
      this.getGoodsInfo()
    },
    methods: {
      getGoodsInfo:function(){
        this.axios({
          method:"get",
          url:'/api/goods?page='+this.page+'&&size='+this.size
        })
          .then(this.getGoodsInfoSucc)
      },
      //请求发送成功后获取数据并显示
      getGoodsInfoSucc:function(res){
        res = res.data;
        console.log(res.data.goods)
        this.goodsList = res.data.goods
        this.count = res.data.count;
        console.log(this.count)
      },
      Update(msg){
        let exp = parseInt(msg.fExpiration)
        let pPrice = parseInt(msg.fPprice)
        let sPrice = parseInt(msg.fSprice)
        this.axios({
          method: "put",
          url: '/api/goods/',
          data: {
            cId:msg.cId,
            cDesc:msg.cDesc,
            cFormat:msg.cFormat,
            cBrand:msg.cBrand,
            cComp:msg.cComp,
            cClass:msg.cClass,
            cBunit:msg.cBunit,
            fExpiration:exp,
            cCode:msg.cCode,
            cQrcode:msg.cQrcode,
            fPprice:pPrice,
            fSprice:sPrice
          }
        })
          .then(this.getGoodsInfo)
      },
      AddMsg(msg){
        let exp = parseInt(msg.fExpiration)
        let pPrice = parseInt(msg.fPprice)
        let sPrice = parseInt(msg.fSprice)
        this.axios({
          method: "post",
          url: '/api/goods/',
          data: {
            cId:msg.cId,
            cDesc:msg.cDesc,
            cFormat:msg.cFormat,
            cBrand:msg.cBrand,
            cComp:msg.cComp,
            cClass:msg.cClass,
            cBunit:msg.cBunit,
            fExpiration:exp,
            cCode:msg.cCode,
            cQrcode:msg.cQrcode,
            fPprice:pPrice,
            fSprice:sPrice
          }
        })
          .then(this.getGoodsInfo)
      },
      Search(name,brand,gclass,comp){
        this.name=name
        this.brand=brand
        this.gclass=gclass
        this.comp=comp
        let string = ''
        if(name!=''){
          string = string+'&&name='+name
        }
        if(brand!=''){
          string = string+'&&brand='+brand
        }
        if(comp!=''){
          string = string+'&&comp='+comp
        }
        if(gclass!=''){
          string = string+'&&classs='+gclass
        }
        console.log(string)
        this.axios({
          method:"get",
          url:'/api/goods?page='+this.page+'&&size='+this.size+string
        })
          .then(this.getGoodsInfoSucc)
      },
      //分页页数改变显示不同的值
      getPage:function (val) {
        let string = ''
        if(this.name!=''){
          string = string+'&&name='+name
        }
        if(this.brand!=''){
          string = string+'&&brand='+brand
        }
        if(this.comp!=''){
          string = string+'&&comp='+comp
        }
        if(this.gclass!=''){
          string = string+'&&classs='+gclass
        }
        this.page = val
        console.log("当前页："+this.page)
        this.axios({
          method:"get",
          url:'/api/goods?page='+this.page+'&&size='+this.size+string
        })
          .then(this.getGoodsInfoSucc)
      },
      //删除
      Delete(list) {
        let array = ''
        for (let i = 0; i < list.length; i++) {
          array = array + list[i] + ","
        }
        // console.log(array)
        this.axios({
          method: "delete",
          url: 'api/goods/' + array
        })
          .then(this.getGoodsInfo)
          .catch((error) => {
            console.log(error);
          })
      },
      //获得价格
      getPrice(id){
        this.axios({
          method:"get",
          url:'/api/sprice?page='+this.page+'&&size='+this.size+'&&cGid='+id
        })
          .then((response)=> {
            // console.log(response);
            response=response.data
            this.goodsPrice = response.data.vendor_goodsprices
            this.count2=response.data.count
          })
      }
    }

  }
</script>

<style scoped>
.com{
  height: 100%;
}
</style>
