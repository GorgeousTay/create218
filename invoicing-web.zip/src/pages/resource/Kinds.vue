<template>
  <div class="kinds">
    <home-header :sid="sid"></home-header>
    <body-left :sid="sid"></body-left>
    <body-right
      :list="classList"
      :count="count"
      :size="size"
      @getCurrentPage="getPage"
      @Delete="Delete"
      @deleteMore="deleteMore"
      @submitChange="Update"
      @getName="getName">
    </body-right>
    <home-bottom></home-bottom>
  </div>
</template>

<script>
  import HomeHeader from '@/pages/home/components/Header'
  import BodyLeft from '@/pages/home/components/BodyLeft'
  import Content from './commodity/Re-Com-ki-content'
  import HomeBottom from '@/pages/home/components/Bottom'
  import axios from 'axios'
  export default {
    name:'Kinds',
    components: {
      HomeHeader: HomeHeader,
      BodyLeft: BodyLeft,
      BodyRight: Content,
      HomeBottom: HomeBottom
    },
    data:function(){
      return{
        classList:'',
        count:0,
        size:10,
        page:1,
        name:''
      }
    },
    methods:{
      //发送显示全部信息的请求
      getPartInfo:function(){
        this.axios({
          method:"get",
          url:'/api/goodsclass?page='+this.page+'&&size='+this.size
        })
          .then(this.getPartInfoSucc)
      },
      //请求发送成功后获取数据并显示
      getPartInfoSucc:function(res){
        res = res.data;
        console.log(res.data.goodsclasss)
        this.classList = res.data.goodsclasss
        this.count = res.data.count;
        console.log(this.count)
      },
      //分页页数改变显示不同的值
      getPage:function (val,name) {
        this.page = val
        console.log("当前页："+this.page)
        this.axios({
          method:"get",
          url:'/api/goodsclass?page='+this.page+'&&size='+this.size+'&&name='+this.name
        })
          .then(this.getPartInfoSucc)
      },
      //根据名字查询信息
      getName:function(val){
        this.name=val
        console.log("查询的名字："+this.name)
        this.axios({
          method:"get",
          url:'/api/goodsclass?page='+this.page+'&&size='+this.size+'&&name='+this.name
        })
          .then(this.getPartInfoSucc)
      },
      //根据id删除信息
      Delete(id){
        this.axios({
          method: "delete",
          url: 'api/goodsclass/' + id
        })
          .then(this.getPartInfo)
          .catch((error) => {
            console.log(error);
          })
      },
      //批量删除
      deleteMore(list){
        let array = ''
        for(let i=0;i<list.length;i++){
          array=array+list[i]+","
        }
        // console.log(array)
        this.axios({
          method: "delete",
          url: 'api/goodsclass/' + array
        })
          .then(this.getPartInfo)
          .catch((error) => {
            console.log(error);
          })
      },
      Update(id,name,order){
        this.axios({
          method: "put",
          url: '/api/goodsclass/',
          data: {
            cClass: id,
            cDesc: name,
            iIdx: order
          }
        })
          .then(this.getPartInfo)
      }
    },
    //点击进该页面自动调用
    mounted(){
      this.getPartInfo()
    },
    created(){
      this.sid = this.$route.query.sid;
    }
  }
</script>

<style scoped>
.kinds{
  height: 100%;
}
</style>
