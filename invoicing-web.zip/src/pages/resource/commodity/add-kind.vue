<template>
  <div class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" >
            <span>×</span>
            <span class="sr-only">关闭弹窗</span>
          </button>
          <h4 class="modal-title" id="MymodalLabel">添加种类</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal">
            <div class="form-group">
              <label for="LabelId" class="col-sm-3 control-label" >种类编号</label>
              <div class="col-md-8">
                <input type="text" class="form-control" v-model="cClass" id="LabelId" placeholder=""/>
              </div>
            </div>
            <div class="form-group">
              <label for="Labe2Id" class="col-sm-3 control-label">种类名称</label>
              <div class="col-md-8">
                <input type="text" class="form-control" v-model="cDesc" id="Labe2Id" placeholder="" />
              </div>
            </div>
            <div class="form-group">
              <label for="Labe3Id" class="col-sm-3 control-label">序号</label>
              <div class="col-md-8">
                <input type="text" class="form-control" v-model="iIdx" id="Labe3Id" placeholder="" />
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary" @click="Create" data-dismiss="modal">确定</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name:'AddKind',
    data:function(){
      return{
        cClass:"",
        cDesc:"",
        iIdx:"",
        page:1,
        size:10
      }
    },
    methods:{
      Create:function(){
        this.axios({
          method:"post",
          url:'/api/goodsclass/',
          data:{
            cClass:this.cClass,
            cDesc:this.cDesc,
            iIdx:this.iIdx
          },
          headers:{
            'Content-Type': 'application/json;charset=UTF-8'
          }
        })
        this.cClass=""
        this.cDesc=""
        this.iIdx=""
      }
    }
  }
</script>

<style scoped>
  .modal{
    z-index: 9999;
    color:#9d9d9d;
  }
  .modal-title{
    font-size:16px;
    color:#080808;
  }
  textarea{
    height:100px;
  }
  .modal-dialog{
    width:500px;
    /*text-align: center;*/
  }
</style>
