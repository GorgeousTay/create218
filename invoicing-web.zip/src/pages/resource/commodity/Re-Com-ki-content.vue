<template>
  <div class="bodyRight">
    <form class="form form-horizontal">
      <fieldset class="fieldset">
        <legend>资源管理/商品库管理/商品种类</legend>
        <div class="btndiv">
          <button class="btn-delete" type="button" @click="DeleteMore(checkedKinds)"><i class="iconfont  iconshanchu">批量删除</i></button>
          <button class="btn-add" type="button" data-toggle="modal" data-target="#addModal"><i class="iconfont icontianjia1">添加职务</i></button>
          <div class=" demo-input-size" style="float: right;width: 30%;">
            <el-input
              placeholder="请输入名称"
              v-model="name"
              style="width: 80%">
            </el-input>
            <el-button @click="Search(name)" icon="el-icon-search" circle></el-button>
          </div>
        </div>
        <div class="table-div">
          <table ref="checkbox" class="table table-border table-bordered table-hover table-bg">
            <thead>
            <tr>
              <th width="25"><el-checkbox  v-model="checkAll"></el-checkbox></th>
              <th width="100">种类编号</th>
              <th width="300">种类名称</th>
              <th width="80">操作</th>
            </tr>
            </thead>
            <tbody>
            <tr class="text-c" v-for="(cclass,index) of list" :key="index">
              <td><el-checkbox class="e-checkbox" :key="cclass.cClass" :true-label="{condition:true,val:cclass.cClass}" :false-label="{condition:false,val:cclass.cClass}"  @change="handleCheckChange"  /></td>
              <td>{{cclass.cClass}}</td>
              <td>{{cclass.cDesc}}</td>
              <td class="f-14">
                <el-button title="编辑" type="button" @click="showDialog(cclass.cClass,cclass.cDesc,cclass.iIdx)" style="text-decoration:none;background-color: rgba(0,0,0,0);border:none;width: 5%"><i class="iconfont  iconweibiaoti520"></i></el-button>
                <a title="删除" href="javascript:;" @click="Delete(cclass.cClass)"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a>
              </td>
            </tr>
            </tbody>
          </table>

          <div class="block">
            <el-pagination
              @current-change="handleCurrentChange"
              :current-page.sync="currentPage"
              :page-size="size"
              :total="count">
            </el-pagination>
          </div>

        </div>
      </fieldset>
    </form>

    <!-- 编辑的模态框 -->
    <el-dialog title="编辑种类" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="种类编号" :label-width="formLabelWidth">
          <el-input v-model="form.cClass" autocomplete="off" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="种类名称" :label-width="formLabelWidth">
          <el-input v-model="form.cDesc" autocomplete="off" ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="changeData">确 定</el-button>
      </div>
    </el-dialog>

    <add-kind id="addModal"></add-kind>

  </div>
</template>

<script>
  import AddKind from './add-kind'
  export default {
    name:'Content',
    props:['list','count','size'],
    components:{
      AddKind
    },
    data:function(){
      return{
        name:'',
        dialogFormVisible:false,
        currentPage:1,  //当前页码
        counts:this.count, //从父组件接收的数据条数总数
        form: {
          cClass: '',
          cDesc: '',
          iIdx: ''
        },
        formLabelWidth: '120px',
        // isIndeterminate: false,
        checkAll: false,
        checkedKinds:[],
        flag:false
      }
    },
    methods:{
      //批量删除
      DeleteMore(){
        this.$emit("deleteMore",this.checkedKinds)
      },
      //当前页数改变
      handleCurrentChange(val) {
        this.$emit("getCurrentPage",val,this.currentName)
      },
      //搜索
      Search(val){
        this.$emit("getName",val)
        this.currentName = val
        this.name=""
      },
      //删除
      Delete:function(id) {
        if (confirm("确定删除该种类？")) {
          this.$emit('Delete',id)
        }
      },
      //弹出框
      showDialog(id,name,order){
        this.dialogFormVisible = true
        this.form.cClass = id
        this.form.cDesc = name
        this.form.iIdx = order
      },
      //编辑
      changeData(){
        this.dialogFormVisible = false
        // alert(this.form.cClass+this.form.cDesc+this.form.iIdx)
        this.$emit("submitChange",this.form.cClass,this.form.cDesc,this.form.iIdx)
      },
      //全选
      // handleCheckAllChange(val){
      //   let checkDom = this.$refs.checkbox.getElementsByClassName('e-checkbox')
      //   // alert(checkDom.length)
      //   if(val){
      //     for(var i=0;i<checkDom.length;i++){
      //       checkDom[i].checked = true;
      //       // console.log(checkDom[i])
      //     }
      //   }else{
      //     for(var i=0;i<checkDom.length;i++){
      //       checkDom[i].checked = false;
      //     }
      //   }
      // },
      //判断是否在数组中
      isInList(val){
        let i = 0
        if(this.checkedKinds.length!=0) {
          for (i; i < this.checkedKinds.length; i++){
            if(this.checkedKinds[i] == val){
              this.flag=true
              break
            }
          }
        }else{
          this.flag=false
        }
        return {con:this.flag,index:i}
      },
      //判断该条信息是否选中并进行删除/添加
      handleCheckChange(val){
        // alert(checked+val)
        this.flag=false
        let con = this.isInList(val.val).con //判断数组里是否有相同的元素，有则true，无则false
        let kindex = this.isInList(val.val).index //判断数组里相同元素的下标
        if(val.condition==true && con==false) {
          this.checkedKinds.push(val.val) //加入数组
        }else if(val.condition==false && con==true) {
          this.checkedKinds.splice(kindex,1) //从数组中删除
        }
        console.log(this.checkedKinds)
      }
    }
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
    padding-top: 1%;
  }
  i{
    font-size: 1em;
  }
  .form{
    width:80%;
    height: 83%;
    margin-left: 18.4%;
  }
  .fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:13%;
    width:98%;
    border-bottom: #E6E6E6 solid 1px;
    padding-bottom: 1.2%;
    float: left;
  }
  .btn-add{
    background-color: #1E9FFF;
    border: #1E9FFF solid 1px;
    border-radius:2px;
    height: 90%;
    width: 10%;
  }
  .btn-add:hover{
    background-color: #3EACFE;
    border: #3EACFE solid 1px;
  }
  .btn-delete{
    background-color: #FF5722;
    border: #FF5722 solid 1px;
    border-radius:2px;
    width: 10%;
    height:90%;
  }
  .btn-delete:hover,.btn-submit:hover{
    background-color: #FD7449;
    border: #FD7449 solid 1px;
  }
  .table-div{
    margin-top: 7.8%;
    /*color:#666666;*/
    height:72%;
    width:98%;
    overflow-y: auto;
    font-size: 1em;
    font-family: "新宋体";
    border-top: #E6E6E6 solid 1px;
    text-align: center;
  }
  th{
    text-align: center;
  }
  .table-hover tr:hover>td{
    background-color: #fbfdff!important;
  }

  .table-hover tr.current-row>td{
    background-color: #fbfdff!important;
  }
</style>
