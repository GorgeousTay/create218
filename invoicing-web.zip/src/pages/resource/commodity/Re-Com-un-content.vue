<template>
  <div class="bodyRight">
  <div class="un-page">
    <div class="un-header">
      <div class="un-search">
        <el-input placeholder = "请输入内容" prefix-icon="el-icon-search" v-model="search"></el-input>
      </div>
      <div class="search-button">
        <el-button type="primary" icon="el-icon-search">查询</el-button>
      </div>
    </div>
    <el-divider content-position="right">单位</el-divider>
    <div class="un-add">
      <el-button type="success" data-toggle="modal" data-target = "#un-addModal" style="font-size: 12px;margin-left: 130px;">+ 添加</el-button>
      <UnAdd id="un-addModal"></UnAdd>
    </div>
    <div class="un-table" style="padding-left: 350px;padding-top: 10px">
      <el-table
        :data="tableData" border
        style="width: 90%" height="340">
        <el-table-column
          label="部门编号"
          prop="c_id">
        </el-table-column>
        <el-table-column
          label="部门名称"
          prop="c_unit">
        </el-table-column>
        <el-table-column
          label="操作" prop="handel">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button
              size="mini"
              type="danger"
              @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="un-buttom" style="padding-left: 500px">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="1000">
      </el-pagination>
    </div>
  </div>
  </div>
</template>

<script>
  import UnAdd from "./Un-add";
  export default {
    name:'Content',
    components: {UnAdd},
    data() {
      return {
        tableData: [{
          c_id: '1',
          c_unit: '瓶',
        }, {
          c_id: '2',
          c_unit: '只',
        },{
          c_id: '1',
          c_unit: '瓶',
        },{
          c_id: '1',
          c_unit: '瓶',
        },{
          c_id: '1',
          c_unit: '瓶',
        },{
          c_id: '1',
          c_unit: '瓶',
        },],
      }
    },
    methods: {
      handleEdit(index, row) {
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      }
    },
  }


</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
  }
  .un-header{
    height: 80px;
    width: 1200px;
    /*border: 1px solid;*/
  }
  .un-search{
    position: absolute;
    top: 80px;
    left: 500px;
  }
  .search-button{
    position: absolute;
    top: 80px;
    left: 730px;
  }
  .un-add{
    height: 40px;
    width: 1200px;
    /*border: 1px solid;*/
  }
  .un-table{
    height: 350px;
    width: 1200px;
    /*border: 1px solid;*/
  }

</style>
