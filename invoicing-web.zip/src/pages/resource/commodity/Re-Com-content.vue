<template>
  <div class="bodyRight">
    <form class="form form-horizontal">
      <fieldset class="fieldset">
        <legend>资源管理-商品库管理</legend>
        <div style="height: 90%;overflow-y: auto">
        <!--搜索-->
        <div class="search-div">
          <el-form  ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <div class=" demo-input-size" style="width:80%;margin-left: 15%">
              <el-input
                placeholder="请输入商品名称"
                v-model="name"
                style="width: 20%">
              </el-input>
              <el-input
                placeholder="请输入商品品牌"
                v-model="brand"
                style="width: 20%">
              </el-input>
              <el-input
                placeholder="请输入商品类别"
                v-model="gclass"
                style="width: 20%">
              </el-input>
              <el-input
                placeholder="请输入商品厂商"
                v-model="comp"
                style="width: 20%">
              </el-input>
              <el-button icon="el-icon-search" @click="Search(name,brand,gclass,comp)" circle></el-button>
            </div>

          </el-form>
        </div>
        <!--按钮-->
        <div class="btndiv">
          <button class="btn-delete" type="button" @click="Delete"><i class="iconfont  iconshanchu">批量删除</i></button>
          <button class="btn-add" type="button" @click="showaddDialog"><i class="iconfont icontianjia1">添加商品</i></button>
        </div>

        <!--表格-->
        <div style="height:100%">
          <el-table :data="list" border style="width: 98%;" :max-height="330">
            <el-table-column fixed style="height:60%" width="35">
              <template slot-scope="scope">
                <el-checkbox @change="Check(scope.row.cId)"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column fixed prop="cId" label="编码" width="150"></el-table-column>
            <el-table-column fixed prop="cDesc" label="名称" width="120"></el-table-column>
            <el-table-column prop="cFormat" label="规格" width="120"></el-table-column>
            <el-table-column prop="cBrand" label="品牌" width="120"></el-table-column>
            <el-table-column prop="cComp" label="厂商" width="120"></el-table-column>
            <el-table-column prop="cClass" label="类别" width="120"></el-table-column>
            <el-table-column prop="cBunit" label="库存单位" width="120"></el-table-column>
            <el-table-column prop="fExpiration" label="保质期" width="120"></el-table-column>
            <el-table-column prop="cCode" label="内部管理条码" width="120"></el-table-column>
            <el-table-column prop="cQrcode" label="国家物品编码体系条码" width="170"></el-table-column>
            <el-table-column prop="fPprice" label="采购价格" width="120"></el-table-column>
            <el-table-column prop="fSprice" label="销售价格" width="100"></el-table-column>
            <el-table-column fixed="right" label="操作" width="130">
              <!-- 查看的框 -->
              <template slot-scope="scope">
                <el-popover
                  placement="right"
                  width="500"
                  trigger="click">
                  <el-table :data="priceList">
                    <el-table-column width="150" property="date" label="日期"></el-table-column>
                    <el-table-column width="100" property="name" label="姓名"></el-table-column>
                    <el-table-column width="300" property="address" label="地址"></el-table-column>
                  </el-table>
                  <el-button slot="reference" type="text" size="small" @click="showPrice(scope.row.cId)">查看</el-button>
                </el-popover>
                <!-- 其他操作 -->
                <el-button style="margin-left: 9%;" type="text" size="small" @click="showDialog(scope.row)">编辑</el-button>
                <!--              <el-button type="text" size="small">删除</el-button>-->
              </template>
            </el-table-column>
          </el-table>

          <!--分页-->
          <div class="block">
            <el-pagination
              style="text-align: center;margin-top: 1%"
              @current-change="handleCurrentChange"
              :current-page.sync="currentPage"
              :page-size="size"
              :total="count">
            </el-pagination>
          </div>
        </div>

          <!-- 编辑的模态框 -->
          <el-dialog title="编辑商品信息" :visible.sync="dialogFormVisible">
            <el-form :model="goodsList">
              <el-form-item size="mini" label="编码" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cId" autocomplete="off" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item size="mini" label="名称" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cDesc" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="规格" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cFormat" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="品牌" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cBrand" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="厂商" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cComp" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="类别" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cClass" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="库存单位" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cBunit" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="保质期" :label-width="formLabelWidth">
                <el-input v-model="goodsList.fExpiration" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="内部管理条码" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cCode" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="国家物品编码体系条码" :label-width="formLabelWidth">
                <el-input v-model="goodsList.cQrcode" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="采购价格" :label-width="formLabelWidth">
                <el-input v-model="goodsList.fPprice" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="销售价格" :label-width="formLabelWidth">
                <el-input v-model="goodsList.fSprice" autocomplete="off" ></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="changeData(goodsList)">确 定</el-button>
            </div>
          </el-dialog>

          <!-- 添加的模态框 -->
          <el-dialog title="添加客户商信息" :visible.sync="dialogAddFormVisible">
            <el-form :model="addgoodsList">
              <el-form-item size="mini" label="编码" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cId" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item size="mini" label="名称" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cDesc" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="规格" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cFormat" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="品牌" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cBrand" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="厂商" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cComp" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="类别" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cClass" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="库存单位" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cBunit" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="保质期" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.fExpiration" autocomplete="off" ></el-input>
<!--                <el-date-picker v-model="addgoodsList.fExpiration" type="date"  placeholder=""  style="width: 100%;"></el-date-picker>-->
              </el-form-item>
              <el-form-item size="mini" label="内部管理条码" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cCode" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="国家物品编码体系条码" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.cQrcode" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="采购价格" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.fPprice" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="销售价格" :label-width="formLabelWidth">
                <el-input v-model="addgoodsList.fSprice" autocomplete="off" ></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="AddMsg(addgoodsList)">确 定</el-button>
            </div>
          </el-dialog>

        </div>
      </fieldset>
    </form>
  </div>
</template>

<script>
  export default {
    name:'Content',
    props:['list','count','size','priceList','count2'],
    data:function () {
      return{
        name:'',//搜索名字
        brand:'',//搜索品牌
        comp:'',//搜索厂商
        gclass:'',//搜索类别
        currentPage:1, //当前页
        collapseChange:false, //折叠面板是否展开
        dialogFormVisible:false, //编辑表单是否可见
        dialogAddFormVisible:false,//添加表单是否可见
        formLabelWidth:'100px',
        flag:false,
        checkList:[],
        goodsList:{
          cId:'',
          cDesc:'',
          cFormat:'',
          cBrand:'',
          cComp:'',
          cClass:'',
          cBunit:'',
          fExpiration:'',
          cCode:'',
          cQrcode:'',
          fPprice:'',
          fSprice:''
        },
        addgoodsList:{
          cId:'',
          cDesc:'',
          cFormat:'',
          cBrand:'',
          cComp:'',
          cClass:'',
          cBunit:'',
          fExpiration:'',
          cCode:'',
          cQrcode:'',
          fPprice:'',
          fSprice:''
        },
      }
    },
    methods:{
      handleCurrentChange(val){
        this.$emit("getCurrentPage",val)
      },
      showDialog(msg){
        this.dialogFormVisible = true
        this.goodsList.cId = msg.cId
        this.goodsList.cDesc = msg.cDesc
        this.goodsList.cFormat = msg.cFormat
        this.goodsList.cBrand = msg.cBrand
        this.goodsList.cComp = msg.cComp
        this.goodsList.cClass = msg.cClass
        this.goodsList.cBunit = msg.cBunit
        this.goodsList.fExpiration = msg.fExpiration
        this.goodsList.cCode = msg.cCode
        this.goodsList.cQrcode = msg.cQrcode
        this.goodsList.fPprice = msg.fPprice
        this.goodsList.fSprice = msg.fSprice
      },
      changeData(msg){
        this.dialogFormVisible = false
        this.$emit("submitChange",msg)
      },
      showaddDialog(){
        this.dialogAddFormVisible = true
      },
      AddMsg(msg){
        this.dialogAddFormVisible = false
        this.$emit("addMsg",msg)
        this.addgoodsList.cId = ''
        this.addgoodsList.cDesc = ''
        this.addgoodsList.cFormat =''
        this.addgoodsList.cBrand =''
        this.addgoodsList.cComp = ''
        this.addgoodsList.cClass = ''
        this.addgoodsList.cBunit = ''
        this.addgoodsList.fExpiration = ''
        this.addgoodsList.cCode = ''
        this.addgoodsList.cQrcode = ''
        this.addgoodsList.fPprice = ''
        this.addgoodsList.fSprice = ''
      },
      Search(name,brand,gclass,comp){
        this.$emit('search',name,brand,gclass,comp)
        // console.log(name+','+brand+','+gclass+','+comp)
        this.name=''
        this.brand=''
        this.gclass=''
        this.comp=''
      },
      //判断是否在数组中
      isInList(val){
        let i = 0
        if(this.checkList.length!=0) {
          for (i; i < this.checkList.length; i++){
            if(this.checkList[i] == val){
              this.flag=true
              break
            }
          }
        }else{
          this.flag=false
        }
        return {con:this.flag,index:i}
      },
      //是否删除
      Check(val){
        // console.log(val)
        this.flag=false
        let con = this.isInList(val).con //判断数组里是否有相同的元素，有则true，无则false
        // console.log(con)
        if(con==false) {
          this.checkList.push(val) //加入数组
        }else if(con==true) {
          let kindex = this.isInList(val).index //判断数组里相同元素的下标
          console.log(kindex)
          this.checkList.splice(kindex,1) //从数组中删除
        }
        console.log(this.checkList)
      },
      //删除
      Delete(){
        this.$emit("delete",this.checkList)
        this.checkList = []
      },
      showPrice(id) {
        // console.log(id)
        this.$emit('getPrice',id)
      }
    }
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
    padding-top: 1%;
  }
  i{
    font-size: 1em;
  }
  .form{
    width:80%;
    height: 83%;
    margin-left: 18.4%;
  }
  .fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .search-div{
    border-bottom: #E6E6E6 solid 1px;
    width:98%;
    padding-bottom: 1.5%;
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:12%;
    width:98%;
    border-bottom: #E6E6E6 solid 1px;
    /*padding-bottom: 1.2%;*/
  }
  .btn-add{
    background-color: #1E9FFF;
    border: #1E9FFF solid 1px;
    border-radius:2px;
    height: 74%;
    width: 10%;
  }
  .btn-add:hover{
    background-color: #3EACFE;
    border: #3EACFE solid 1px;
  }
  .btn-delete{
    background-color: #FF5722;
    border: #FF5722 solid 1px;
    border-radius:2px;
    width: 10%;
    height:74%;
  }
  .btn-delete:hover,.btn-submit:hover{
    background-color: #FD7449;
    border: #FD7449 solid 1px;
  }
  .table-div{
    margin-top: 2%;
    /*color:#666666;*/
    height:57%;
    width:98%;
    overflow-y: auto;
    /*overflow-x: auto;*/
    overflow-x:scroll;
    font-size: 1em;
    font-family: "新宋体";
    border-top: #E6E6E6 solid 1px;
    text-align: center;
  }
  .table{
    table-layout:fixed;
    word-break:break-all;
  }
  th{
    text-align: center;
  }
  .table-hover tr:hover>td{
    background-color: #fbfdff!important;
  }

  .table-hover tr.current-row>td{
    background-color: #fbfdff!important;
  }
</style>
