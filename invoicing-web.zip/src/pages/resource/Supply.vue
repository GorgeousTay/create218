<template>
  <div class="supply">
    <home-header :sid="sid"></home-header>
    <body-left :sid="sid"></body-left>
    <body-right
      :list="supList"
      :count="count"
      :size="size"
      @getCurrentPage="getPage"
      @submitChange="Update"
      @delete="Delete"
      @search="Search"
      @addSup="addSup">
    </body-right>
    <home-bottom></home-bottom>
  </div>
</template>

<script>
  import HomeHeader from '@/pages/home/components/Header'
  import BodyLeft from '@/pages/home/components/BodyLeft'
  import Content from './supply/Re-Su-content'
  import HomeBottom from '@/pages/home/components/Bottom'
  export default {
    name:'Supply',
    components: {
      HomeHeader: HomeHeader,
      BodyLeft: BodyLeft,
      BodyRight: Content,
      HomeBottom: HomeBottom
    },
    data:function(){
      return{
        page:1,//初始页数是第一页
        size:10,//每页显示10条
        count:0,//获取的总条数
        supList:[],//供应商列表
        addr:'',
        sale:'',
        supply:'',
        contacter:''
      }
    },
    created(){
      this.sid = this.$route.query.sid;
    },
    mounted(){
      this.getSupplyInfo()
    },
    methods:{
      getSupplyInfo:function(){
        this.axios({
          method:"get",
          url:'/api/vendor?page='+this.page+'&&size='+this.size
        })
          .then(this.getSupInfoSucc)
      },
      //请求发送成功后获取数据并显示
      getSupInfoSucc:function(res){
        res = res.data;
        console.log(res.data.vendors)
        this.supList = res.data.vendors
        this.count = res.data.count;
        console.log(this.count)
      },
      //更新
      Update(msg){
        if(msg.iStatus=='0'){
          msg.iStatus = 0
        }else if(msg.iStatus=='1'){
          msg.iStatus = 1
        }
        this.axios({
          method: "put",
          url: '/api/vendor/',
          data: {
            cId:msg.cId,
            cName:msg.cName,
            cVclass:msg.cVclass,
            cAddr:msg.cAddr,
            cTele:msg.cTele,
            cFax:msg.cFax,
            cZip:msg.cZip,
            cGcode:msg.cGcode,
            cCorporation:msg.cCorporation,
            cContacter:msg.cContacter,
            cMphone:msg.cMphone,
            cSale:msg.cSale,
            cBank:msg.cBank,
            cBacc:msg.cBacc,
            cBlpic:msg.cBlpic,
            cCpic:msg.cCpic,
            iStatus:msg.iStatus,
            cComment:msg.cComment
          }
        })
          .then(this.getSupplyInfo)
      },
      //添加
      addSup(msg){
        if(msg.iStatus=='0'){
          msg.iStatus = 0
        }else if(msg.iStatus=='1'){
          msg.iStatus = 1
        }
        this.axios({
          method: "post",
          url: '/api/vendor/',
          data: {
            cId:msg.cId,
            cName:msg.cName,
            cVclass:msg.cVclass,
            cAddr:msg.cAddr,
            cTele:msg.cTele,
            cFax:msg.cFax,
            cZip:msg.cZip,
            cGcode:msg.cGcode,
            cCorporation:msg.cCorporation,
            cContacter:msg.cContacter,
            cMphone:msg.cMphone,
            cSale:msg.cSale,
            cBank:msg.cBank,
            cBacc:msg.cBacc,
            cBlpic:msg.cBlpic,
            cCpic:msg.cCpic,
            iStatus:msg.iStatus,
            cComment:msg.cComment
          }
        })
          .then(this.getSupplyInfo)
      },
      //分页页数改变显示不同的值
      getPage:function (val) {
        this.page = val
        console.log("当前页："+this.page)
        this.axios({
          method:"get",
          url:'/api/vendor?page='+this.page+'&&size='+this.size+'&&name='+this.supply+'&&addr='+this.addr+'&&contacter='+this.contacter+'&&salename='+this.sale
        })
          .then(this.getSupInfoSucc)
      },
      //删除
      Delete(list){
        let array = ''
        for(let i=0;i<list.length;i++){
          array=array+list[i]+","
        }
        console.log('删除列表：'+array)
        this.axios({
          method: "delete",
          url: 'api/vendor/' + array
        })
          .then(this.getSupplyInfo)
          .catch((error) => {
            console.log(error);
          })
      },
      //搜索
      Search(addr,sale,supname,conname){
        // console.log("地址："+addr+",业务员："+sale+"，客户商："+cusname+"，接洽人："+conname)
        this.addr = addr
        this.sale = sale
        this.supply = supname
        this.contacter = conname
        this.axios({
          method:"get",
          url:'/api/vendor?page='+this.page+'&&size='+this.size+'&&name='+this.supply+'&&addr='+this.addr+'&&contacter='+this.contacter+'&&salename='+this.sale
        })
          .then(this.getSupInfoSucc)

      }
    }
  }
</script>

<style scoped>
.supply{
  height: 100%;
}
</style>
