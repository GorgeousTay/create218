<template>
  <div class="customer">
    <home-header :sid="sid"></home-header>
    <body-left :sid="sid"></body-left>
    <body-right
      :list="cusList"
      :count="count"
      :size="size"
      @getCurrentPage="getPage"
      @submitChange="Update"
      @delete="Delete"
      @search="Search"
      @addCus="addCus">
    </body-right>
    <home-bottom></home-bottom>
  </div>
</template>

<script>
  import HomeHeader from '@/pages/home/components/Header'
  import BodyLeft from '@/pages/home/components/BodyLeft'
  import Content from './customer/Re-Cus-content'
  import HomeBottom from '@/pages/home/components/Bottom'
  export default {
    name:'Customer',
    components: {
      HomeHeader: HomeHeader,
      BodyLeft: BodyLeft,
      BodyRight: Content,
      HomeBottom: HomeBottom
    },
    data:function(){
      return{
        page:1,//初始页数是第一页
        size:10,//每页显示10条
        count:0,//获取的总条数
        cusList:[],//客户商列表
        addr:'',
        sale:'',
        cusname:'',
        conname:''
      }
    },
    created(){
      this.sid = this.$route.query.sid;
    },
    mounted(){
      this.getCustomerInfo()
    },
    methods:{
      getCustomerInfo:function(){
        this.axios({
          method:"get",
          url:'/api/customer?page='+this.page+'&&size='+this.size
        })
          .then(this.getCusInfoSucc)
      },
      //请求发送成功后获取数据并显示
      getCusInfoSucc:function(res){
        res = res.data;
        console.log(res.data.customers)
        this.cusList = res.data.customers
        this.count = res.data.count;
        console.log(this.count)
      },
      //更新
      Update(msg){
        if(msg.iStatus=='0'){
          msg.iStatus = 0
        }else if(msg.iStatus=='1'){
          msg.iStatus = 1
        }
        this.axios({
          method: "put",
          url: '/api/customer/',
          data: {
            cId:msg.cId,
            cName:msg.cName,
            cAreaid:msg.cAreaid,
            cAddr:msg.cAddr,
            cTele:msg.cTele,
            cFax:msg.cFax,
            cZip:msg.cZip,
            cGcode:msg.cGcode,
            cCorporation:msg.cCorporation,
            cContacter:msg.cContacter,
            cMphone:msg.cMphone,
            cSale:msg.cSale,
            iStatus:msg.iStatus
          }
        })
          .then(this.getCustomerInfo)
      },
      //添加
      addCus(msg){
        if(msg.iStatus=='0'){
          msg.iStatus = 0
        }else if(msg.iStatus=='1'){
          msg.iStatus = 1
        }
        this.axios({
          method: "post",
          url: '/api/customer/',
          data: {
            cId:msg.cId,
            cName:msg.cName,
            cAreaid:msg.cAreaid,
            cAddr:msg.cAddr,
            cTele:msg.cTele,
            cFax:msg.cFax,
            cZip:msg.cZip,
            cGcode:msg.cGcode,
            cCorporation:msg.cCorporation,
            cContacter:msg.cContacter,
            cMphone:msg.cMphone,
            cSale:msg.cSale,
            iStatus:msg.iStatus
          }
        })
          .then(this.getCustomerInfo)
      },
      //分页页数改变显示不同的值
      getPage:function (val) {
        this.page = val
        console.log("当前页："+this.page)
        this.axios({
          method:"get",
          url:'/api/customer?page='+this.page+'&&size='+this.size+'&&name='+this.cusname+'&&addr='+this.addr+'&&contacter='+this.conname+'&&salename='+this.sale
        })
          .then(this.getCusInfoSucc)
      },
      //删除
      Delete(list){
        let array = ''
        for(let i=0;i<list.length;i++){
          array=array+list[i]+","
        }
        // console.log(array)
        this.axios({
          method: "delete",
          url: 'api/customer/' + array
        })
          .then(this.getCustomerInfo)
          .catch((error) => {
            console.log(error);
          })
      },
      //搜索
      Search(addr,sale,cusname,conname){
        // console.log("地址："+addr+",业务员："+sale+"，客户商："+cusname+"，接洽人："+conname)
        this.addr = addr
        this.sale = sale
        this.cusname = cusname
        this.conname = conname
        this.axios({
          method:"get",
          url:'/api/customer?page='+this.page+'&&size='+this.size+'&&name='+this.cusname+'&&addr='+this.addr+'&&contacter='+this.conname+'&&salename='+this.sale
        })
          .then(this.getCusInfoSucc)

      }
    }
  }
</script>

<style scoped>
.customer{
  height: 100%;
}
</style>
