<template>
  <div id="page">
    <div class="hea">
      <div class="logo">
        <div class="titl">
          <div class="h1">
          </div>
          <span>
                        invoicing
          </span>
        </div>
        <span>
                    |为了保证信息安全 请勿将您的账号信息泄露给他人|
        </span>
      </div>
    </div>
    <div class="con">
      <div class="left_text">
        <h1>invoicing进销存,</h1>
        <h1>带给你高效的办公新体验</h1>
      </div>
      <div class="register">
        <div class="title">
          <span>登陆</span>
          <a href="#">

            "没有账号>>去注册"
          </a>
        </div>
        <form method="post" action="#">
          <div class="default">
            <input type="text"  id="unum" name="unum" v-model="unum">
            <div class="identify"> <label for="unum">账号</label></div>
          </div>
          <div class="default">
            <input type="password" id="pwd" name="pwd" v-model="pwd">
            <div class="identify"> <label for="pwd">密码</label>
            </div>
          </div>
          <div class="default">
            <input type="text" name="inputCode" id="inputCode" v-model="inputCode" placeholder="请输入验证码"
                   style="width: 180px;height: 38px;font-size: 16px;float: left;text-align:center;">
            <input class="code" v-model="checkCode" @click="creatCode" readonly unselectable="on"   style="width: 100px "></input>
          </div>
          <div class="submit">
            <button type="submit" @click="login">登陆</button>
          </div>

        </form>
        <div class="default">
          <a href="#">忘记密码</a>
        </div>

      </div>
      <div>

      </div>

    </div>

  </div>
</template>

<script >
    export default {
      name: "Login",
      data(){
        return{
         unum:'',
         dialog:false,
          unum:'',
          pwd:'',
          inputCode: '',
          checkCode:'',
        }
      },
      methods: {

        creatCode:function() {
          console.log("sa");
          var code = "";
          var codeLength = 4;
          var checkCode = this.checkCode;
          var selectChar = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
          for (var i = 0; i < codeLength; i++) {
            var charIndex = Math.floor(Math.random() * 62);
            code += selectChar[charIndex];
          }
          console.log(code);
          /*if (checkCode)
          {*/
           this.checkCode = code;
          //}
        },
        login:function () {
          if(this.unum == ''){
            alert("请输入账号");
          }
          if(this.pwd == ''){
            alert("请输入密码");
          }
          var checkCode = this .checkCode;
          var inputCode = this.inputCode;
          console.log(checkCode);
          console.log(inputCode);
          if (inputCode.length<=0){
            alert("请输入验证码！");
          }else if (inputCode.toUpperCase() != checkCode.toUpperCase()){
            alert("验证码输入有误！");
            creatCode();
          }

        }
      },
      created() {
        this.creatCode();
      }

    }

</script>

<style scoped>
  *{
    margin: 0;
    padding: 0;
  }

  div{
    display: block;
  }
  body{
    font-family: "微软雅黑";
    background-color: #f5f5f5;
  }
  #page{
    background-image: url("../../assets/LoginImage/login_back.jpg");
    background-size: cover;
    height: calc(50vm);
    min-height: 700px;
    max-height: calc(100vh - 92px);
  }
  .hea{
    /*position: absolute;*/
    padding: 22px 0;
    height: 44px;
    /*border: 1px solid;*/
  }
  .logo{
    width: 1000px;
    margin: 0 auto;
    /*border: 1px solid;*/
  }
  .titl{
    width: 140px;
    height: 28px;
    float: left;
    /*background-image: url(" ");*/
    /*border: 1px solid;*/
  }
  .titl>.h1{
    width: 50px;
    height: 28px;
    background-image: url("../../assets/LoginImage/logo.png ");
    float: left;
    /*border: 1px solid;*/
  }
  .logo>.titl span{
    width: 90px;
    font-size: 22px;
    color: #4B6EA4;
  }
  .logo span{
    font-size: 13px;
    /*font-family: "PingFang SC";*/
    float: right;
    color: #2B2B2B;
  }
  .con{
    width: 1350px;
    height: 630px;
    position: relative;
    /*border: 1px solid;*/
  }
  .left_text{
    position: absolute;
    float: left;
    text-align: left;
    margin-top: 260px;
    margin-left:180px;
    font-size: 34px;
    color: #385d91;
    letter-spacing: 3px;
    /*border: 1px solid;*/
    /*text-shadow: 0 2px 24px rgba(255,255,255,.5);*/
  }
  .register{
    width: 360px;
    height: 360px;
    /*background: rgba(225,225,225,1);*/
    background: #fff;
    position: absolute;
    top: 125px;
    left: 850px;
    /*border: 1px solid;*/
  }
  .register>.title{
    margin-top: 20px;
    height: 30px;
    /*padding-left: 40px;*/
    /*padding-right: 20px;*/
    width: 280px;
    margin: 0 auto;
    padding-top: 20px;
    padding-bottom: 25px;
    /*border: 1px solid;*/
  }
  .register>.title>span{
    width: 40px;
    height: 30px;
    font-size: 18px;
    color: #333333;
  }
  .register>.title>a{
    display: inline-block;
    float: right;
    font-size: 14px;
    color: #111;
    text-decoration: none;
    text-align: center;
  }
  /*.register>.title{*/
  /*  font-size: 12px;*/
  /*}*/
  .default{
    width: 290px;
    height: 38px;
    margin-top: 15px;
    margin-bottom: 5px;
    margin-left: 30px;
    position: relative;
    /*border: 1px solid;*/
  }
  .identify{
    height: 38px;
    width: 45px;
    font-size: 15px;
    padding-top: 9px;
    text-align: center;
    border-radius: 3px;
    color: #424242;
    background-color: #fff;
    border: 1px solid #cccccc;
  }
  .default>input{
    width: 240px;
    height: 38px;
    float: right;
    border: 1px solid #cccccc;
    border-radius: 3px;
  }
  .code{
    font-family: Arial;
    color: #4B6EA4;
    font-size: 20px;
    float: right;
    width: 100px;
    height: 38px;
    text-align: center;
    background-color: #d8b7e3;
    /*margin-left: 30px;*/
    padding-top: 10px;
  }
  .submit button{
    margin: 0;
    padding: 0;
    border: 0;
    margin-left: 40px;
    margin-top: 30px;
    width: 280px;
    line-height: 38px;
    text-align: center;
    font-size: 16px;
    color: #fff;
    border-radius: 3px;
    cursor: pointer;
    background: #4B6EA4;
  }
  .default a{
    float: right;
  }

</style>
