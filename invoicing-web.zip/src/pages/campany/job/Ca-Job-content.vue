<template>
  <div class="bodyRight">
      <form class="form form-horizontal">
        <fieldset class="fieldset">
          <legend>企业管理-职务设置</legend>
          <div class="btndiv">
            <button class="btn-delete" type="button" @click="Click"><i class="iconfont  iconshanchu">批量删除</i></button>
            <button class="btn-add" type="button" data-toggle="modal" data-target="#addModal"><i class="iconfont icontianjia1">添加职务</i></button>
          </div>
          <div class="table-div">
          <table class="table table-border table-bordered table-hover table-bg">
            <thead>
            <tr>
              <th width="25"><input type="checkbox" value="" name=""></th>
              <th width="100">职务编号</th>
              <th width="300">职务名称</th>
              <th width="400">描述</th>
              <th width="80">操作</th>
            </tr>
            </thead>
            <tbody>
            <tr class="text-c" v-for="jobs of list" :key="jobs.cDid">
              <td><input type="checkbox" value="" name=""></td>
              <td>{{jobs.cDid}}</td>
              <td>{{jobs.cDepartment}}</td>
              <td>{{jobs.cComment}}</td>
              <td class="f-14"><a title="编辑" href="javascript:;"  style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a>
                <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>
            </tr>
<!--            <tr class="text-c">-->
<!--              <td><input type="checkbox" value="" name=""></td>-->
<!--              <td>2</td>-->
<!--              <td>总编</td>-->
<!--&lt;!&ndash;              <td><a href="#">张三</a></td>&ndash;&gt;-->
<!--              <td>具有添加、审核、发布、删除内容的权限</td>-->
<!--              <td class="f-14"><a title="编辑" href="javascript:;" style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a> <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>-->
<!--            </tr>-->
<!--            <tr class="text-c">-->
<!--              <td><input type="checkbox" value="" name=""></td>-->
<!--              <td>3</td>-->
<!--              <td>栏目主辑</td>-->
<!--&lt;!&ndash;              <td><a href="#">李四</a>，<a href="#">王五</a></td>&ndash;&gt;-->
<!--              <td>只对所在栏目具有添加、审核、发布、删除内容的权限</td>-->
<!--              <td class="f-14"><a title="编辑" href="javascript:;"  style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a> <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>-->
<!--            </tr>-->
<!--            <tr class="text-c">-->
<!--              <td><input type="checkbox" value="" name=""></td>-->
<!--              <td>4</td>-->
<!--              <td>栏目编辑</td>-->
<!--&lt;!&ndash;              <td><a href="#">赵六</a>，<a href="#">钱七</a></td>&ndash;&gt;-->
<!--              <td>只对所在栏目具有添加、删除草稿等权利。</td>-->
<!--              <td class="f-14"><a title="编辑" href="javascript:;"  style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a> <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>-->
<!--            </tr>-->

<!--            <tr class="text-c">-->
<!--              <td><input type="checkbox" value="" name=""></td>-->
<!--              <td>1</td>-->
<!--              <td>超级管理员</td>-->
<!--              &lt;!&ndash;              <td><a href="#">admin</a></td>&ndash;&gt;-->
<!--              <td>拥有至高无上的权利</td>-->
<!--              <td class="f-14"><a title="编辑" href="javascript:;"  style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a> <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>-->
<!--            </tr>-->
<!--            <tr class="text-c">-->
<!--              <td><input type="checkbox" value="" name=""></td>-->
<!--              <td>2</td>-->
<!--              <td>总编</td>-->
<!--              &lt;!&ndash;              <td><a href="#">张三</a></td>&ndash;&gt;-->
<!--              <td>具有添加、审核、发布、删除内容的权限</td>-->
<!--              <td class="f-14"><a title="编辑" href="javascript:;"  style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a> <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>-->
<!--            </tr>-->
<!--            <tr class="text-c">-->
<!--              <td><input type="checkbox" value="" name=""></td>-->
<!--              <td>3</td>-->
<!--              <td>栏目主辑</td>-->
<!--              &lt;!&ndash;              <td><a href="#">李四</a>，<a href="#">王五</a></td>&ndash;&gt;-->
<!--              <td>只对所在栏目具有添加、审核、发布、删除内容的权限</td>-->
<!--              <td class="f-14"><a title="编辑" href="javascript:;"  style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a> <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>-->
<!--            </tr>-->
<!--            <tr class="text-c">-->
<!--              <td><input type="checkbox" value="" name=""></td>-->
<!--              <td>4</td>-->
<!--              <td>栏目编辑</td>-->
<!--              &lt;!&ndash;              <td><a href="#">赵六</a>，<a href="#">钱七</a></td>&ndash;&gt;-->
<!--              <td>只对所在栏目具有添加、删除草稿等权利。</td>-->
<!--              <td class="f-14"><a title="编辑" href="javascript:;"  style="text-decoration:none"><i class="iconfont  iconweibiaoti520"></i></a> <a title="删除" href="javascript:;"  class="ml-5" style="text-decoration:none"><i class="iconfont  iconshanchu"></i></a></td>-->
<!--            </tr>-->
            </tbody>
          </table>
          </div>
        </fieldset>
      </form>
    <add-job id="addModal"></add-job>
  </div>
</template>

<script>
  import AddJob from './add-job'
  export default {
    name:'Content',
    props:["list"],
    components:{
      AddJob
    },
    data:function(){
      return{
        // jobList:this.list
      }
    },
    methods:{
      Click(){

      }
    }
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
    padding-top: 1%;
  }
  i{
    font-size: 1em;
  }
  .form{
    width:80%;
    height: 83%;
    margin-left: 18.4%;
  }
  .fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:13%;
    width:98%;
    border-bottom: #E6E6E6 solid 1px;
    padding-bottom: 1.2%;
    float: left;
  }
  .btn-add{
    background-color: #1E9FFF;
    border: #1E9FFF solid 1px;
    border-radius:2px;
    height: 90%;
    width: 10%;
  }
  .btn-add:hover{
    background-color: #3EACFE;
    border: #3EACFE solid 1px;
  }
  .btn-delete{
    background-color: #FF5722;
    border: #FF5722 solid 1px;
    border-radius:2px;
    width: 10%;
    height:90%;
  }
  .btn-delete:hover,.btn-submit:hover{
    background-color: #FD7449;
    border: #FD7449 solid 1px;
  }
  .table-div{
    margin-top: 2%;
    /*color:#666666;*/
    height:72%;
    width:98%;
    overflow-y: auto;
    font-size: 1em;
    font-family: "新宋体";
    border-top: #E6E6E6 solid 1px;
    text-align: center;
  }
  th{
    text-align: center;
  }
</style>
