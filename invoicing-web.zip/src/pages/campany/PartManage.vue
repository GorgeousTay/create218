<template>
  <div class="home">
    <home-header :sid="sid"></home-header>
    <body-left :sid="sid"></body-left>
    <body-right
      :list="partList"
      :page="pagesList"
      @add="Add">
    </body-right>
    <home-bottom></home-bottom>
  </div>
</template>

<script>
  import HomeHeader from '@/pages/home/components/Header'
  import BodyLeft from '@/pages/home/components/BodyLeft'
  import Content from './partComponents/content'
  import HomeBottom from '@/pages/home/components/Bottom'
  import axios from 'axios'

  export default {
    name:'PartManage',
    components: {
      HomeHeader: HomeHeader,
      BodyLeft: BodyLeft,
      BodyRight: Content,
      HomeBottom: HomeBottom
    },
    data:function(){
      return{
        partList:[],
        pagesList:[]
      }
    },
    created(){
      this.sid = this.$route.query.sid;
    },
    methods:{
      getPartInfo:function(){
        axios.get('/api/department')
          .then(this.getPartInfoSucc)
      },
      getPartInfoSucc:function(res){
        res = res.data;
        // var num = 1;
        console.log("sss"+res.data.list)
        this.partList = res.data.list
        for(var i=0;i<res.data.pages;i++){
          this.pagesList.push(i+1)
        }
        console.log(this.pagesList)
      },
      Add(id,name,comment){
        console.log('Main模块：'+id+','+name+','+comment)
        this.axios({
          method:"post",
          url:'/api/department/',
          data:{
            cDid:id,
            cDepartment: name,
            cComment: comment
          }
        })
          .then(this.getPartInfo)
      }
    }
    ,
    mounted(){
      this.getPartInfo()
    }
  }
</script>

<style scoped>
  .home{
    height: 100%;
  }
</style>
