<template>
  <div class="bodyRight">
    <form class="form form-horizontal">
      <fieldset class="fieldset">
        <legend>企业管理-员工管理</legend>
        <div style="height: 90%;overflow-y: auto">
        <div class="search-div">
          <el-form  ref="ruleForm" label-width="100px" class="demo-ruleForm">
<!--            <el-col :span="6">-->
<!--              <el-form-item label="日期范围:" >-->
<!--                <el-date-picker type="date"  placeholder="开始日期"  style="width: 100%;"></el-date-picker>-->
<!--              </el-form-item>-->
<!--            </el-col>-->
<!--            <el-col :span="6">-->
<!--              <el-form-item label-width="30px" label="-">-->
<!--                <el-date-picker type="date"  placeholder="截止日期"  style="width: 70%;"></el-date-picker>-->
<!--              </el-form-item>-->
<!--            </el-col>-->
            <el-col :span="16" style="margin-left: 16%">
              <el-form-item label-width="60">
                <el-input placeholder="请输入内容" v-model="text" class="input-with-select">
                  <el-select v-model="select"  slot="prepend" placeholder="请选择" style="width: 100px;">
                    <el-option label="工号" value="工号"></el-option>
                    <el-option label="姓名" value="姓名"></el-option>
                    <el-option label="手机号" value="手机号"></el-option>
                    <el-option label="性别" value="性别"></el-option>
                    <el-option label="状态" value="状态"></el-option>
                  </el-select>
                  <el-button slot="append" icon="el-icon-search"></el-button>
                </el-input>
              </el-form-item>
            </el-col>
            <hr>
            <hr>
          </el-form>
        </div>
        <div class="btndiv">
          <button class="btn-delete" type="button"><i class="iconfont  iconshanchu">批量删除</i></button>
          <button class="btn-add" type="button" @click="showaddDialog"><i class="iconfont icontianjia1">添加用户</i></button>
<!--          <span style="color:#5e5e5e;float:right;margin-top: 1%">共有数据：<b>10</b>条</span>-->
        </div>

        <div style="height:100%">
          <el-table :data="test" border style="width: 98%;" :max-height="330">
            <el-table-column fixed style="height:60%" width="35">
              <template slot-scope="scope">
                <el-checkbox @change="Check(scope.row.cId)"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column fixed prop="cNumber" label="工号" width="150"></el-table-column>
            <el-table-column fixed prop="cName" label="名称" width="120"></el-table-column>
            <el-table-column prop="iSex" label="性别" width="120"></el-table-column>
            <el-table-column prop="cEducation" label="学历" width="120"></el-table-column>
            <el-table-column prop="cId" label="身份证" width="120"></el-table-column>
            <el-table-column prop="cAddress" label="家庭地址" width="120"></el-table-column>
            <el-table-column prop="cMobile" label="手机号" width="120"></el-table-column>
            <el-table-column prop="cLinkman" label="家庭联系人" width="120"></el-table-column>
            <el-table-column prop="cLmmobile" label="联系人手机号" width="120"></el-table-column>
            <el-table-column prop="dtJoin" label="入职时间" width="230"></el-table-column>
            <el-table-column prop="dtLeft" label="离职时间" width="230"></el-table-column>
            <el-table-column prop="iStatus" :formatter="statusFormat" label="状态" width="100"></el-table-column>
            <el-table-column prop="cIdpic" label="员工身份证照正面" width="100"></el-table-column>
            <el-table-column prop="cIdpicl" label="员工身份证照反面" width="100"></el-table-column>
            <el-table-column prop="cPic" label="员工近照" width="100"></el-table-column>
            <el-table-column prop="tsCtime" label="创建时间" width="230"></el-table-column>
            <el-table-column prop="duty.cDuty" label="职务" width="100"></el-table-column>
            <el-table-column prop="department.cDid" label="部门" width="100"></el-table-column>
            <el-table-column fixed="right" label="操作" width="130">

              <template slot-scope="scope">
                <!-- 其他操作 -->
                <el-button style="margin-left: 9%;" type="text" size="small" @click="showDialog(scope.row)">编辑</el-button>
                <!--              <el-button type="text" size="small">删除</el-button>-->
              </template>
            </el-table-column>
          </el-table>

          <!-- 添加的模态框 -->
          <el-dialog title="添加员工信息" :visible.sync="dialogAddFormVisible">
            <el-form :model="addMsg">
              <el-form-item size="mini" label="工号" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cNumber" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="姓名" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cName" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item size="mini" label="性别" :label-width="formLabelWidth">
                <el-radio v-model="addMsg.iSex" label="0">男</el-radio>
                <el-radio v-model="addMsg.iSex" label="1">女</el-radio>
              </el-form-item>
              <el-form-item size="mini" label="学历" :label-width="formLabelWidth">
                <el-select v-model="addMsg.cEducation" placeholder="请选择">
                  <el-option label="小学" value="小学"></el-option>
                  <el-option label="初中" value="初中"></el-option>
                  <el-option label="高中" value="高中"></el-option>
                  <el-option label="本科" value="本科"></el-option>
                  <el-option label="硕士" value="硕士"></el-option>
                  <el-option label="硕士以上" value="硕士以上"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item size="mini" label="身份证" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cId" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="家庭地址" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cAddress" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="手机号" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cMobile" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="家庭联系人" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cLinkman" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="联系人手机号" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cLmmobile" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="入职时间" :label-width="formLabelWidth">
                <el-date-picker type="date" v-model="addMsg.dtJoin"  placeholder="" ></el-date-picker>              </el-form-item>
              <el-form-item size="mini" label="离职时间" :label-width="formLabelWidth">
                <el-date-picker type="date" v-model="addMsg.dtLeft"  placeholder="" ></el-date-picker>
              </el-form-item>
              <el-form-item size="mini" label="状态" :label-width="formLabelWidth">
                <!--              <el-input v-model="cusMsg.iStatus" autocomplete="off" ></el-input>-->
                <el-radio v-model="addMsg.iStatus" label="0">在职</el-radio>
                <el-radio v-model="addMsg.iStatus" label="1">离职</el-radio>
                <el-radio v-model="addMsg.iStatus" label="2">退休</el-radio>
              </el-form-item>
              <el-form-item size="mini" label="员工身份证照正面" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cIdpic" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="员工身份证照反面" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cIdpicl" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="员工近照" :label-width="formLabelWidth">
                <el-input v-model="addMsg.cPic" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="创建时间" :label-width="formLabelWidth">
                <el-date-picker type="date" v-model="addMsg.tsCtime"  placeholder="" ></el-date-picker>
              </el-form-item>
              <el-form-item size="mini" label="职务" :label-width="formLabelWidth">
<!--                <el-select v-model="addMsg.duty.cId" placeholder="请选择">-->
<!--                  <el-option label="小学" value="小学"></el-option>-->
<!--                  <el-option label="初中" value="初中"></el-option>-->
<!--                  <el-option label="高中" value="高中"></el-option>-->
<!--                  <el-option label="本科" value="本科"></el-option>-->
<!--                  <el-option label="硕士" value="硕士"></el-option>-->
<!--                  <el-option label="硕士以上" value="硕士以上"></el-option>-->
<!--                </el-select>-->
                <el-input v-model="addMsg.duty.cId" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="部门" :label-width="formLabelWidth">
                <el-input v-model="addMsg.department.cDid" autocomplete="off" ></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogAddFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="AddMsg(addMsg)">确 定</el-button>
            </div>
          </el-dialog>

          <!-- 编辑的模态框 -->
          <el-dialog title="编辑员工信息" :visible.sync="dialogFormVisible">
            <el-form :model="Msg">
              <el-form-item size="mini" label="工号" :label-width="formLabelWidth">
                <el-input v-model="Msg.cNumber" autocomplete="off" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item size="mini" label="姓名" :label-width="formLabelWidth">
                <el-input v-model="Msg.cName" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item size="mini" label="性别" :label-width="formLabelWidth">
                <el-radio v-model="Msg.iSex" label="0">男</el-radio>
                <el-radio v-model="Msg.iSex" label="1">女</el-radio>
              </el-form-item>
              <el-form-item size="mini" label="学历" :label-width="formLabelWidth">
                <el-select v-model="Msg.cEducation" placeholder="请选择">
                  <el-option label="小学" value="小学"></el-option>
                  <el-option label="初中" value="初中"></el-option>
                  <el-option label="高中" value="高中"></el-option>
                  <el-option label="本科" value="本科"></el-option>
                  <el-option label="硕士" value="硕士"></el-option>
                  <el-option label="硕士以上" value="硕士以上"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item size="mini" label="身份证" :label-width="formLabelWidth">
                <el-input v-model="Msg.cId" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="家庭地址" :label-width="formLabelWidth">
                <el-input v-model="Msg.cAddress" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="手机号" :label-width="formLabelWidth">
                <el-input v-model="Msg.cMobile" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="家庭联系人" :label-width="formLabelWidth">
                <el-input v-model="Msg.cLinkman" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="联系人手机号" :label-width="formLabelWidth">
                <el-input v-model="Msg.cLmmobile" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="入职时间" :label-width="formLabelWidth">
                <el-date-picker type="date" v-model="addMsg.dtJoin"  placeholder="" ></el-date-picker>              </el-form-item>
              <el-form-item size="mini" label="离职时间" :label-width="formLabelWidth">
                <el-date-picker type="date" v-model="addMsg.dtLeft"  placeholder="" ></el-date-picker>
              </el-form-item>
              <el-form-item size="mini" label="状态" :label-width="formLabelWidth">
                <!--              <el-input v-model="cusMsg.iStatus" autocomplete="off" ></el-input>-->
                <el-radio v-model="Msg.iStatus" label="0">在职</el-radio>
                <el-radio v-model="Msg.iStatus" label="1">离职</el-radio>
                <el-radio v-model="Msg.iStatus" label="2">退休</el-radio>
              </el-form-item>
              <el-form-item size="mini" label="员工身份证照正面" :label-width="formLabelWidth">
                <el-input v-model="Msg.cIdpic" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="员工身份证照反面" :label-width="formLabelWidth">
                <el-input v-model="Msg.cIdpicl" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="员工近照" :label-width="formLabelWidth">
                <el-input v-model="Msg.cPic" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="创建时间" :label-width="formLabelWidth">
                <el-date-picker type="date" v-model="Msg.tsCtime"  placeholder="" ></el-date-picker>
              </el-form-item>
              <el-form-item size="mini" label="职务" :label-width="formLabelWidth">
                <!--                <el-select v-model="addMsg.duty.cId" placeholder="请选择">-->
                <!--                  <el-option label="小学" value="小学"></el-option>-->
                <!--                  <el-option label="初中" value="初中"></el-option>-->
                <!--                  <el-option label="高中" value="高中"></el-option>-->
                <!--                  <el-option label="本科" value="本科"></el-option>-->
                <!--                  <el-option label="硕士" value="硕士"></el-option>-->
                <!--                  <el-option label="硕士以上" value="硕士以上"></el-option>-->
                <!--                </el-select>-->
                <el-input v-model="Msg.duty.cId" autocomplete="off" ></el-input>
              </el-form-item>
              <el-form-item size="mini" label="部门" :label-width="formLabelWidth">
                <el-input v-model="Msg.department.cDid" autocomplete="off" ></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="AddMsg(addMsg)">确 定</el-button>
            </div>
          </el-dialog>

          <!--分页-->
          <div class="block">
            <el-pagination
              style="text-align: center;margin-top: 1%"
              @current-change="handleCurrentChange"
              :current-page.sync="currentPage"
              :page-size="size"
              :total="count">
            </el-pagination>
          </div>
        </div>
        </div>
      </fieldset>
    </form>
  </div>
</template>

<script>
  export default {
    name:'Content',
    props:['list','count','size'],
    data:function(){
      return {
        select:'',
        text:'',
        currentPage:1, //当前页
        collapseChange:false, //折叠面板是否展开
        formLabelWidth:'130px', //表单Label宽度
        dialogFormVisible:false, //编辑表单是否可见
        dialogAddFormVisible:false,//添加表单是否可见
        checkedList:[], //批量删除列表
        flag:false,

        test:[
          {
            cNumber:'1',
            cName:'1',
            iSex:'1',
            cEducation:'1',
            cId:'1',
            cAddress:'1',
            cMobile:'1',
            cLinkman:'1',
            cLmmobile:'1',
            dtJoin:'',
            dtLeft:'',
            iStatus:'0',
            cIdpic:'',
            cIdpicl:'',
            cPic:'',
            tsCtime:'',
            duty:{
              cId:'1',
              cDuty:'1',
              cComment:'1'
            },
            department:{}
          }
        ],

        Msg:{  //存储当前正在编辑的客户信息
          cNumber:'',
          cName:'',
          iSex:'0',
          cEducation:'',
          cId:'',
          cAddress:'',
          cMobile:'',
          cLinkman:'',
          cLmmobile:'',
          dtJoin:'',
          dtLeft:'',
          iStatus:'0',
          cIdpic:'',
          cIdpicl:'',
          cPic:'',
          tsCtime:'',
          duty:{
            cId:'',
            cDuty:'',
            cComment:''
          },
          department:{
            cDid:'',
            cDepartment:'',
            cComment:''
          }
        },
        addMsg:{  //存储当前正在添加的客户信息
          cNumber:'',
          cName:'',
          iSex:'0',
          cEducation:'',
          cId:'',
          cAddress:'',
          cMobile:'',
          cLinkman:'',
          cLmmobile:'',
          dtJoin:'',
          dtLeft:'',
          iStatus:'0',
          cIdpic:'',
          cIdpicl:'',
          cPic:'',
          tsCtime:'',
          duty:{
            cId:'',
            cDuty:'',
            cComment:''
          },
          department:{
            cDid:'',
            cDepartment:'',
            cComment:''
          }
        }
      }
    },
    methods:{
      statusFormat(row,column){
        switch(row.iStatus){
          case 0:
            return '在职';
            break;
          case 1:
            return '离职';
            break;
          case 2:
            return '退休';
            break;
          default:
            return '未知'
        }
      },
      handleCurrentChange(val){
        this.$emit("getCurrentPage",val)
      },
      //弹出添加框
      showaddDialog(){
        this.dialogAddFormVisible = true
      },
      //弹出编辑框
      showDialog(msg){
        this.dialogFormVisible = true
        this.Msg.cNumber = msg.cNumber
        this.Msg.cName = msg.cName
        // this.Msg.iSex = String(msg.iSex)
        this.Msg.iSex = msg.iSex
        // if(msg.iSex==0){
        //   this.Msg.iSex = '0'
        // }else if(Msg.iSex==1) {
        //   this.Msg.iSex = '1'
        // }
        this.Msg.cEducation = msg.cEducation
        this.Msg.cAddress = msg.cAddress
        this.Msg.cMobile = msg.cMobile
        this.Msg.cLinkman  = msg.cLinkman
        this.Msg.cLmmobile  = msg.cLmmobile
        this.Msg.dtJoin  = msg.dtJoin
        this.Msg.dtLeft  = msg.dtLeft
        this.Msg.iStatus = msg.iStatus
        // if(msg.iStatus==0){
        //   this.Msg.iStatus = '0'
        // }else if(msg.iStatus==1){
        //   this.Msg.iStatus = '1'
        // }else if(msg.iStatus==2){
        //   this.Msg.iStatus = '2'
        // }
        this.Msg.cIdpic  = msg.cIdpic
        this.Msg.cIdpicl  = msg.cIdpicl
        this.Msg.cPic  = msg.cPic
        this.Msg.tsCtime   = msg.tsCtime
        this.Msg.duty.cId  = msg.duty.cId
        this.Msg.department.cId  = msg.department.cId
      },
      //显示状态的值
      statusFormat(row,column){
        switch(row.iStatus){
          case 0:
            return '正常';
            break;

          case 1:
            return '停用';
            break;
          default:
            return '未知'
        }
      },
      //编辑
      changeData(cusMsg){
        this.dialogFormVisible = false
        // alert(this.form.cClass+this.form.cDesc+this.form.iIdx)
        this.$emit("submitChange",cusMsg)
      },
      //添加
      AddMsg(msgList){
        // alert(msgList.cId+msgList.constructor)
        this.dialogAddFormVisible = false
        this.$emit("addMsg",msgList)
        this.addMsg.cNumber = ''
        this.addMsg.cName = ''
        this.addMsg.iSex = '0'
        this.addMsg.cEducation = ''
        this.addMsg.cAddress = ''
        this.addMsg.cMobile = ''
        this.addMsg.cLinkman  = ''
        this.addMsg.cLmmobile  = ''
        this.addMsg.dtJoin  = ''
        this.addMsg.dtLeft  = ''
        this.addMsg.iStatus  = '0'
        this.addMsg.cIdpic  = ''
        this.addMsg.cIdpicl  = ''
        this.addMsg.cPic  = ''
        this.addMsg.tsCtime   = ''
        this.addMsg.duty.cId  = ''
        this.addMsg.department.cId  = ''
      },

      handleShowRow(msg) {
        console.log(msg);
      },
      //判断是否在数组中
      isInList(val){
        let i = 0
        if(this.checkedCustomer.length!=0) {
          for (i; i < this.checkedCustomer.length; i++){
            if(this.checkedCustomer[i] == val){
              this.flag=true
              break
            }
          }
        }else{
          this.flag=false
        }
        return {con:this.flag,index:i}
      },
      //是否删除
      Check(val){
        // console.log(val)
        this.flag=false
        let con = this.isInList(val).con //判断数组里是否有相同的元素，有则true，无则false
        // console.log(con)
        if(con==false) {
          this.checkedCustomer.push(val) //加入数组
        }else if(con==true) {
          let kindex = this.isInList(val).index //判断数组里相同元素的下标
          console.log(kindex)
          this.checkedCustomer.splice(kindex,1) //从数组中删除
        }
        console.log(this.checkedCustomer)
      },
      //删除
      Delete(){
        this.$emit("delete",this.checkedCustomer)
        this.checkedCustomer = []
      },
      //搜索
      Search(addr1,addr2,sale,cusname,conname){
        let addr = addr1+addr2
        this.$emit('search',addr,sale,cusname,conname)
        this.addr1=''
        this.addr2=''
        this.sale=''
        this.cusname=''
        this.conname=''
      }
    }
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
    padding-top: 1%;
  }
  i{
    font-size: 1em;
  }
  .form{
    width:80%;
    height: 83%;
    margin-left: 18.4%;
  }
  .fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .search-div{
    border-bottom: #E6E6E6 solid 1px;
    width:98%;
    padding-bottom: 1.5%;
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:12%;
    width:98%;
    border-bottom: #E6E6E6 solid 1px;
    /*padding-bottom: 1.2%;*/
  }
  .btn-add{
    background-color: #1E9FFF;
    border: #1E9FFF solid 1px;
    border-radius:2px;
    height: 74%;
    width: 10%;
  }
  .btn-add:hover{
    background-color: #3EACFE;
    border: #3EACFE solid 1px;
  }
  .btn-delete{
    background-color: #FF5722;
    border: #FF5722 solid 1px;
    border-radius:2px;
    width: 10%;
    height:74%;
  }
  .btn-delete:hover,.btn-submit:hover{
    background-color: #FD7449;
    border: #FD7449 solid 1px;
  }
  .table-div{
    margin-top: 2%;
    /*color:#666666;*/
    height:57%;
    width:98%;
    overflow-y: auto;
    /*overflow-x: auto;*/
    overflow-x:scroll;
    font-size: 1em;
    font-family: "新宋体";
    border-top: #E6E6E6 solid 1px;
    text-align: center;
  }
  .table{
    table-layout:fixed;
    word-break:break-all;
  }
  th{
    text-align: center;
  }
  .table-hover tr:hover>td{
    background-color: #fbfdff!important;
  }

  .table-hover tr.current-row>td{
    background-color: #fbfdff!important;
  }
</style>
