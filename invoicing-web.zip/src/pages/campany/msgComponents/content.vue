<template>
  <div class="bodyRight">
    <form class="form form-horizontal">
      <fieldset class="fieldset">
        <legend>企业管理-公司信息设置</legend>
        <div class="btndiv">
          <button class="btnedit" type="button" @click="Click"><i class="iconfont  iconweibiaoti520">编辑</i></button>
          <button class="btnrefresh" type="button"><i class="iconfont iconshuaxin">刷新</i></button>
        </div>
        <fieldset class="fieldset2">
          <div class="table-div">
            <el-form ref="ruleForm" label-width="150px" class="demo-ruleForm table" :disabled="disabled">
              <el-col :span="20">
                <el-form-item label="企业名称:" >
                  <el-input background="#CCCCCC" value="仓库公司"></el-input>
                </el-form-item>
                <el-form-item label="企业简称:"  >
                  <el-input background="#CCCCCC" style="width:50%" value="仓库公司"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="20">
                <el-form-item label="所在城市:" >
                  <el-select v-model="city">
<!--                    <el-option :v-for="(item,index) of BusinessNature" :label="item" :value="index"></el-option>-->
                    <el-option label="合肥市" value="type1"></el-option>
                    <el-option label="芜湖市" value="tyep2"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="20">
                <el-form-item label="详细地址:" >
                  <el-input v-model="addr" background="#CCCCCC" ></el-input>
                </el-form-item>
              </el-col>
                <el-col :span="15">
                  <el-form-item label="成立时间:" >
                    <el-date-picker type="date"  placeholder="开始日期"  style="width: 100%;"></el-date-picker>
                  </el-form-item>
                </el-col>
              <el-col :span="10">
                <el-form-item label="经纬度:" >
                  <el-input value="70">
                    <el-select v-model="select1"  slot="prepend" placeholder="请选择" style="width: 100px;">
                      <el-option label="东经" value="东经"></el-option>
                      <el-option label="西经" value="西经"></el-option>
                    </el-select>
                    <template slot="append">度</template>
                  </el-input>
                  <el-input value="70">
                    <el-select v-model="select2"  slot="prepend" placeholder="请选择" style="width: 100px;">
                      <el-option label="南纬" value="东经"></el-option>
                      <el-option label="北纬" value="西经"></el-option>
                    </el-select>
                    <template slot="append">度</template>
                  </el-input>
                </el-form-item>
              </el-col>
<!--              <el-col :span="20">-->
<!--                <el-form-item label="员工人数:" >-->
<!--                  <el-radio v-model="radio" label="1">1-20人</el-radio>-->
<!--                  <el-radio v-model="radio" label="2">21-50人</el-radio>-->
<!--                  <el-radio v-model="radio" label="3">51-100人</el-radio>-->
<!--                  <el-radio v-model="radio" label="4">100人以上</el-radio>-->
<!--                </el-form-item>-->
<!--              </el-col>-->
              <el-col :span="20" v-if="show">
                <el-form-item >
                  <button class="btn-submit" type="submit">立即提交</button>
                  <button class="btn-reset" type="reset">重置</button>
                </el-form-item>
              </el-col>
            </el-form>
        </div>
        </fieldset>
      </fieldset>
    </form>
  </div>
</template>

<script>
  export default {
    name: 'Content',
    data:function(){
      return{
        sid:2,
        radio:'1',
        show:false,
        nature:"",
        disabled:true,
        select1:'',
        select2:'',
        date:new Date()
        // options: {
        //   format: 'YYYY-MM-DD',
        //   useCurrent: false,
        //   locale: 'zh-cn',
        //   tooltips: {
        //     selectTime: ''
        //   }
        // }
      }
    },
    methods:{
      Click:function(){
        // alert("aaa")
        this.show=true
        this.disabled=false
      }
    }
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
    font-family: Arial;
    padding-top: 1%;
  }
  .form{
    width:80%;
    height: 82%;
    margin-left: 18.4%;
  }
  .fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:7%
  }
  .btnedit{
    background-color: #1E9FFF;
    border: #1E9FFF solid 1px;
    border-radius:2px;
    height: 100%;
    width: 6%;
  }
  .btnedit:hover{
    background-color: #3EACFE;
    border: #3EACFE solid 1px;
  }
  .btnrefresh{
    background-color: #009688;
    border: #009688 solid 1px;
    border-radius:2px;
    width: 6%;
    height:100%;
  }
  .btnrefresh:hover,.btn-submit:hover{
    background-color: #2FA89D;
    border: #2FA89D solid 1px;
  }
  .btn-submit{
    background-color: #009688;
    border: #009688 solid 1px;
    border-radius:2px;
    height: 100%;
    width: 18%;
    font-size: 0.9em;
    color: #ffffff;
    font-family: "微软雅黑";
    margin-left: 35px;
    margin-top: 10px;
  }
  .btn-reset{
    border: #d4d4d4 solid 1px;
    border-radius:2px;
    height: 100%;
    width: 18%;
    font-size: 0.9em;
    color: #5e5e5e;
    font-family: "微软雅黑";
    margin-left: 2%;
  }
  i{
    font-size: 0.9em;
  }
  .fieldset2{
    height:90%;
  }
.table-div{
  margin-top: 2%;
  color:#666666;
  height:85%;
  overflow-y: auto;
  font-size: 1.15em;
  font-family: "新宋体";
  border-top: #E6E6E6 solid 1px;
}
  .table{
    margin-top: 2%;
    margin-left: 3%;
    height:100%;
    width: 85%;
  }
  .head{
    color:#222222;
    font-family: "字魂5号-无外润黑体";
  }
  .form-control{
    border-radius: 3px;
    width:100%;
    font-size: 1em;
    color: #A3A3A3;
  }
  .input-group{
    padding-left: 1.8%;
  }
</style>
