<template>
  <div class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" >
            <span>×</span>
            <span class="sr-only">关闭弹窗</span>
          </button>
          <h4 class="modal-title" id="MymodalLabel">添加仓库信息</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal">
            <div class="form-group">
              <label for="LabelId" class="col-sm-3 control-label" >单位编号</label>
              <div class="col-md-8">
                <input type="text" class="form-control" v-model="cid" id="LabelId" placeholder=""/>
              </div>
            </div>
            <div class="form-group">
              <label for="Labe2Id" class="col-sm-3 control-label">仓库名称</label>
              <div class="col-md-8">
                <input type="text" class="form-control" v-model="cname" id="Labe2Id" placeholder="" />
              </div>
              <div class="form-group">
                <label for="Labe3Id" class="col-sm-3 control-label">地址</label>
                <div class="col-md-8">
                  <textarea class="form-control"  v-model="cads" id="Labe3Id" placeholder="" />
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary"  data-dismiss="modal">确定</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: "addWa",
      data: function () {
        return{
          cid:'',
          cname:'',
          cads:'',
        }
      },
      methods: {
        click() {

        }
      }
    }
</script>

<style scoped>
  .modal{
    z-index: 9999;
    color:#9d9d9d;
  }
  .modal-title{
    font-size:16px;
    color:#080808;
  }
  textarea{
    margin-top: 2%;
    height:100px;
  }
  .modal-dialog{
    width:500px;
    /*text-align: center;*/
  }
</style>
