<template>
  <div class="bodyRight">
    <form class="wa-form">
    <fieldset>
      <legend>仓库管理-仓库设置</legend>
      <div class="btndiv">
        <el-button class="btn-add" type="primary" data-toggle="modal" data-target="#wa-model"><i class="el-icon-plus">添加仓库</i></el-button>
        <add-wa id="wa-model"></add-wa>
      </div>
      <div class="table-div">
        <el-table :data="tableData" border style="width: 100%" height="350">
          <el-table-column prop="cid" label="仓库编号" width="200">
          </el-table-column>
          <el-table-column prop="cname" label="仓库名称" width="220">
          </el-table-column>
          <el-table-column prop="cads" label="仓库地址" width="260">
          </el-table-column>
          <el-table-column prop="handle" label="操作" width="280">
            <template slot-scope="scope">
              <el-button type="info"><i class="el-icon-edit">编辑</i></el-button>
              <el-button type="danger"><i class="el-icon-delete" @click="Delete">删除</i></el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="un-buttom" style="padding-left: 25% ;padding-top: 1.5%">
        <el-pagination
          background
          layout="prev, pager, next"
          :total="1000">
        </el-pagination>
      </div>
    </fieldset>
    </form>
  </div>
</template>

<script>
  import AddWa from './addWa'
  export default {
    name:'Content',
    components:{
      AddWa:AddWa
    },
    data(){
      return{
        tableData:[{
          cid:'1',
          cname:'仓库一',
          cads:'安徽省合肥市蜀山区',
        },{
          cid:'1',
          cname:'仓库一',
          cads:'安徽省合肥市蜀山区',
        },{
          cid:'1',
          cname:'仓库一',
          cads:'安徽省合肥市蜀山区',
        },{
          cid:'1',
          cname:'仓库一',
          cads:'安徽省合肥市蜀山区',
        },{
          cid:'1',
          cname:'仓库一',
          cads:'安徽省合肥市蜀山区',
        },{
          cid:'1',
          cname:'仓库一',
          cads:'安徽省合肥市蜀山区',
        },{
          cid:'1',
          cname:'仓库一',
          cads:'安徽省合肥市蜀山区',
        }]
      }
    },
    methods:{
      click(){

      },
      Delete:function () {
        if (confirm("确定删除该部门？")){
          this.axios({
            method:"delete",
            url:"",
          })
            .then((response)=> {
              console.log(response);
            })
            .catch((error)=>{
              console.log(error);
            })
        }
      },
    },
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
  }
  .wa-form{
    width:80%;
    height: 82%;
    margin-left: 18.4%;
  }
  fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:13%;
    width:98%;
    border-bottom: #E6E6E6 solid 1px;
    padding-bottom: 1.2%;
  }
  .table-div{
    padding-top: 1.2%;
    border-top: #E6E6E6 solid 1px;
  }
</style>
