<template>
  <div class="role">
    <home-header :sid="sid"></home-header>
    <body-left :sid="sid"></body-left>
    <body-right
      :list="roleList"
      :count="count"
      :size="size"
      :grants="grants"
      :addgrants="addgrants"
      @getCurrentPage="getPage"
      @findRole="findRole"
      @selectroles="Selectroles"
      @selectGrants="selectGrants"
      @addRoleGrand="addRoleGrand"
      @deleteRoleGrand="deleteRoleGrand"
      @addRole="addRole"
      @updateRole="updateRole"
      @deleteRole="deleteRole"
    ></body-right>
    <home-bottom></home-bottom>
  </div>
</template>

<script>
  import HomeHeader from '@/pages/home/components/Header'
  import BodyLeft from '@/pages/home/components/BodyLeft'
  import Content from './role/Sys-Ro-content'
  import HomeBottom from '@/pages/home/components/Bottom'
  export default {
    name:'Role',
    components: {
      HomeHeader: HomeHeader,
      BodyLeft: BodyLeft,
      BodyRight: Content,
      HomeBottom: HomeBottom
    },
    data:function(){
      return{
        sid:1,
        page:1,//初始页数是第一页
        size:10,//每页显示10条
        count:0,//获取的总条数
        name:'',//查询的名字
        roleList:[],//客户商列表
        grants:[],
        addgrants:[],//角色权限表
      }
    },
    created(){
      this.sid = this.$route.query.sid;
    },
    mounted(){
      this.getRoleInfo()
    },
    methods:{
      getRoleInfo:function(){
        this.axios({
          method:"get",
          url:'/api/role?page='+this.page+'&&size='+this.size+'&&name='+this.name
        })
          .then(this.getRoleInfoSucc)
      },
      //请求发送成功后获取数据并显示
      getRoleInfoSucc:function(res){
        res = res.data;
        console.log(res.data.roles)
        this.roleList = res.data.roles
        this.count = res.data.count;
        console.log(this.count)
      },
      Selectroles:function (roleid) {
        // alert(roleid)
        this.axios({
          method:"get",
          url:'/api/roleid/'+roleid

        })
          .then(this.getGrants)
      },
      getGrants:function (res) {
        this.grants=res.data.data;
      },
      selectGrants:function (roleid) {
        this.axios({
          method:"get",
          url:'/api/grant/'+roleid

        })
          .then(this.getaddgrants)
      },
      getaddgrants:function (res) {
        this.addgrants=res.data.data;
      },
      addRoleGrand:function (rolegrant) {
        this.axios({
          method:"post",
          url:'/api/rolegrand/',
          data:{
            cRoleid:rolegrant.cRoleid,
            cGrantid:rolegrant.cGrantid,
          }
        })
          .then(res=>{
            if(res.data.status==200){
              this.Selectroles(rolegrant.cRoleid)
              this.selectGrants(rolegrant.cRoleid)
              this.$message({
                message: '增加权限成功',
                type: 'success'
              });
            }else{
              this.$message({
                message: '失败,不要点太快',
                type: 'warning'
              });
            }
          })
      },
      deleteRoleGrand:function (rolegrant) {
        this.axios({
          method:"delete",
          url:'/api/rolegrand/',
          data:{
            cRoleid:rolegrant.cRoleid,
            cGrantid:rolegrant.cGrantid,
          }
        })
          .then(res=>{
            if(res.data.status==200){
              this.Selectroles(rolegrant.cRoleid)
              this.selectGrants(rolegrant.cRoleid)
              this.$message({
                message: '删除权限成功',
                type: 'success'
              });
            }else{
              this.$message({
                message: '失败,不要点太快',
                type: 'warning'
              });
            }
          })
      },
      addRole:function (role) {
        this.axios({
          method:"post",
          url:'/api/role/',
          data:{
            cRoleid:role.cRoleid,
            cRole:role.cRole,
          }
        })
          .then(res=>{
            if(res.data.status==200){
              this.getRoleInfo()
              this.$message({
                message: '添加成功',
                type: 'success'
              });
            }else{
              this.$message({
                message: '添加失败',
                type: 'warning'
              });
            }
          })
      },
      updateRole:function () {
        this.axios({
          method:"put",
          url:'/api/role/',
          data:{
            cRoleid:role.cRoleid,
            cRole:role.cRole,
          }
        })
          .then(res=>{
            if(res.data.status==200){
              this.getRoleInfo()
              this.$message({
                message: '更改成功',
                type: 'success'
              });
            }else{
              this.$message({
                message: '更改失败',
                type: 'warning'
              });
            }
          })
      },
      getPage:function (val) {
        this.page = val
        this.getRoleInfo()
      },
      findRole:function (name) {
        this.name=name
        this.getRoleInfo()
      },
      deleteRole:function (ids) {
        this.axios({
          method:"delete",
          url:'/api/role/'+ids,
        })
          .then(res=>{
            if(res.data.status==200){
              this.getRoleInfo()
              this.$message({
                message: '删除成功',
                type: 'success'
              });
            }else{
              this.$message({
                message: '删除失败',
                type: 'warning'
              });
            }
          })
      },
    }
  }
</script>

<style scoped>
.role{
  height: 100%;
}
</style>
