<template>
  <div class="bodyRight">
    log
  </div>
</template>

<script>
  export default {
    name:'Content'
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
  }
</style>
