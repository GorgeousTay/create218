<template>
  <div class="bodyRight">
    <form class="form form-horizontal">
      <!--set是个框-->
      <fieldset class="fieldset">
        <legend>系统管理-权限设置</legend>
        <div style="height: 90%;overflow-y: auto">
        <!--按钮+搜索-->
        <div class="btndiv">
          <button class="btn-delete" type="button" plain="true" @click="deleteRole"><i class="iconfont  iconshanchu">批量删除</i></button>

          <button class="btn-add" type="button" plain="true" @click="dialogFormVisible = true" ><i class="iconfont icontianjia1">添加角色</i></button>
          <el-dialog title="添加角色" :visible.sync="dialogFormVisible">
            <el-form :model="role">
              <el-form-item label="角色编号" :label-width="formLabelWidth">
                <el-input v-model="role.cRoleid" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="角色名称" :label-width="formLabelWidth">
                <el-input v-model="role.cRole" autocomplete="off"></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="addRole(role),dialogFormVisible = false">确 定</el-button>
            </div>
          </el-dialog>


          <div class=" demo-input-size" style="float: right;width: 38%">
            <el-input
              placeholder="请输入角色名称"
              v-model="name"
              style="width: 43.5%">
            </el-input>
            <el-button icon="el-icon-search" @click="findRole(name)"  circle></el-button>
          </div>
        </div>
        <!--表格-->
        <div style="height:100%">
          <el-table :data="list" border  style="width: 98%;" :max-height="collapseChange==true? '180%' : '450%'" @selection-change="handleSelectionChange">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="cRoleid" label="角色编号" align='center' ></el-table-column>
            <el-table-column prop="cRole" label="角色名称" align='center' ></el-table-column>
            <el-table-column fixed="right" label="操作" align='center' width="200">
              <template slot-scope="scope">
                <!--查看权限-->
                <el-popover
                  placement="right"
                  width="200"
                  trigger="click">
                  <el-table :data="grants" :max-height="300">
                    <el-table-column prop="cGrant" label="权限名称" align='center' ></el-table-column>
                    <el-table-column fixed="right" label="操作" align='center' >
                      <template slot-scope="scope3">
                      <el-button type="text" plain="true" size="small" icon="el-icon-remove-outline" @click="deleteRoleGrand(scope.row.cRoleid,scope3.row.cGrantid)"></el-button>
                      </template>
                    </el-table-column>
                  </el-table>

                  <!--增加权限-->
                  <div align='center'>
                    <el-popover
                      placement="right"
                      width="200"
                      trigger="click">
                      <el-table :data="addgrants" :max-height="300">
                        <el-table-column prop="cGrant" label="权限名称" align='center' ></el-table-column>
                        <el-table-column fixed="right" label="操作" align='center' >
                          <template slot-scope="scope2">
                          <el-button type="text"  size="small" icon="el-icon-circle-plus-outline" @click="addRoleGrand(scope.row.cRoleid,scope2.row.cGrantid)"></el-button>
                          </template>
                        </el-table-column>
                      </el-table>
                      <el-button slot="reference" type="primary" round @click=" selectGrants(scope.row.cRoleid)" >增加权限</el-button>
                    </el-popover>
                  </div>

                  <el-button slot="reference" type="text" size="small" @click=" selectroles(scope.row.cRoleid)" >查看权限</el-button>
                </el-popover>

                <!--编辑-->
                <el-button style="margin-left: 9%;" plain="true" type="text" size="small" @click="showUpdate(scope.row)">编辑</el-button>

              </template>
            </el-table-column>
          </el-table>
          <!--分页-->
          <div class="block">
            <el-pagination
              style="text-align: center"
              @current-change="getPage"
              :current-page.sync="currentPage"
              :page-size="size"
              :total="count">
            </el-pagination>
          </div>
        </div>


        <el-dialog title="编辑" :visible.sync="dialogUpdate">
          <el-form :model="role">
            <el-form-item label="角色编号" :label-width="formLabelWidth">
              <el-input v-model="role.cRoleid" autocomplete="off" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="角色名称" :label-width="formLabelWidth">
              <el-input v-model="role.cRole" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogUpdate = false">取 消</el-button>
            <el-button plain="true" type="primary"  @click="updateRole(role),dialogUpdate = false">确 定</el-button>
          </div>
        </el-dialog>
        </div>
      </fieldset>
    </form>
  </div>
</template>

<script>
  export default {
    name:'Content',
    // 返回接受值
    props:['list','count','size','grants','addgrants'],
    data:function () {
      return{
        currentPage:'', //当前页
        formLabelWidth:'120px', //表单Label宽度
        dialogFormVisible:false, //编辑表单是否可见
        dialogUpdate:false,
        multipleSelection: [],//多选内容
        name:'',
        rolegrant:{
          cRoleid:'',
          cGrantid:'',
        },
        role:{
          cRoleid:'',
          cRole:'',
        }
      }
    },
    methods:{
      //分页
      getPage(val){
        this.$emit("getCurrentPage",val)
      },
      findRole(name){
        this.$emit("findRole",name)
      },//多选
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      deleteRole(){
        this.$confirm('此操作将永久删除, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          var ids=''
          var length=this.multipleSelection.length
          for(var i=0;i<length;i++){
            ids=ids+this.multipleSelection[i].cRoleid+","
          }
          this.$emit("deleteRole",ids)
          this.multipleSelection=[]
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });

      },
      //查看权限
      selectroles:function (roleid) {
        // alert(roleid);
        this.$emit("selectroles",roleid)
      },//查看没有的权限
      selectGrants:function (roleid) {
        this.$emit("selectGrants",roleid)
      },//怎加权限
      addRoleGrand:function (roleid,grantid) {
        this.rolegrant.cRoleid=roleid
        this.rolegrant.cGrantid=grantid
        this.$emit("addRoleGrand",this.rolegrant)
      },//删除权限
      deleteRoleGrand:function (roleid,grantid) {
        this.rolegrant.cRoleid=roleid
        this.rolegrant.cGrantid=grantid
        this.$emit("deleteRoleGrand",this.rolegrant)
      },
      addRole:function (role) {
        this.$emit("addRole",role)
      },
      showUpdate:function (role) {
        this.role=role
        this.dialogUpdate=true
      },
      updateRole:function (role) {
        this.$emit("updateRole",role)
      },
    }
  }
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 100%;
    background: #F5F5F5;
    font-size: 0.9em;
    padding-top: 1%;
  }
  i{
    font-size: 1em;
  }
  .form{
    width:80%;
    height: 83%;
    margin-left: 18.4%;
  }
  .fieldset {
    position: inherit;
    padding-left:2%;
    height:96%;
    border: 1px solid #E6E6E6;
  }
  legend {
    padding: .5em;
    border: 0;
    width: auto;
    font-size: 1.35em;
    font-family: "微软雅黑 light";
  }
  .btndiv{
    padding-top: 1%;
    color:#ffffff;
    height:13%;
    width:98%;
    border-bottom: #E6E6E6 solid 1px;
    padding-bottom: 1.2%;
    float: left;
  }
  .btn-add{
    background-color: #1E9FFF;
    border: #1E9FFF solid 1px;
    border-radius:2px;
    height: 90%;
    width: 10%;
  }
  .btn-add:hover{
    background-color: #3EACFE;
    border: #3EACFE solid 1px;
  }
  .btn-delete{
    background-color: #FF5722;
    border: #FF5722 solid 1px;
    border-radius:2px;
    width: 10%;
    height:90%;
  }
  .btn-delete:hover,.btn-submit:hover{
    background-color: #FD7449;
    border: #FD7449 solid 1px;
  }

</style>
