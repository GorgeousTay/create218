<template>
  <div style="height: 98%; overflow-y: auto">

  </div>
</template>

<script>
import Schart from 'vue-schart';

export default {
  data() {
    return {

      
      
    }
  },
  components: {
    Schart
  },
  computed: {
    
  },
 
   
  methods: {

  
  }
}
</script>

<style scoped>


</style>
