<template>
  <div>
        <div class="bottom"></div>
  </div>
</template>

<script>
  export default {
    name:'HeaderBottom'
  }
</script>

<style>
  .bottom{
    z-index: 9997;
    position: fixed;
    bottom: 0;
    width: 100%;
    margin-left: 10%;
    padding: 15px;
    background-color: #EBEBEB;
    text-align: center;
  }
</style>
