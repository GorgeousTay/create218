<template>
    <div class="bodyRight">
      <el-table
        :data="tableData. filter(data => !search || data.iNo.toLowerCase().includes(search.toLowerCase()))"
        border
        :default-sort = "{prop: 'dtDt', order: 'descending'}"
        style="width: 100%">
        <el-table-column type="expand">
          <template slot-scope="props">
              <el-table
                :data="props.row.detailList"
                stripe>
                <el-table-column
                  label="商品"
                  width="110"
                  prop="goods.cDesc">
                </el-table-column>
                <el-table-column
                  label="销售数量"
                  width="90"
                  prop="fQuant">
                  <template slot-scope="scope">
                    <input style="width: 55px" v-model="scope.row.fQuant"></input>{{scope.row.cBunit}}
                  </template>
                </el-table-column>
                <el-table-column
                  label="单价"
                  width="90"
                  prop="fPrice">
                </el-table-column>
                <el-table-column
                  label="合计"
                  width="90"
                  prop="fAmount">
                </el-table-column>
              </el-table>
          </template>
        </el-table-column>
        <el-table-column
          label="销售单号"
          width="130"
          prop="iNo">
        </el-table-column>
        <el-table-column
          label="客户商编号"
          width="100"
          prop="cCid">
        </el-table-column>
        <el-table-column
          prop="dtDt"
          label="日期"
          sortable
          width="100">
        </el-table-column>
        <el-table-column
          label="操作员"
          width="90"
          prop="cClerk">
        </el-table-column>
        <el-table-column
          label="审核"
          prop="cCheck">
        </el-table-column>
        <el-table-column
          label="审核时间"
          prop="dtCheck">
        </el-table-column>
        <el-table-column
          label="反审核人"
          prop="cCheckout">
        </el-table-column>
        <el-table-column
          label="反审核时间"
          prop="dtCheckout">
        </el-table-column>
        <el-table-column
          label="作废人"
          prop="cInvalid">
        </el-table-column>
        <el-table-column
          label="作废时间"
          prop="dtInvalid">
        </el-table-column>
        <el-table-column
          label="对应出库单号"
          prop="iBono">
        </el-table-column>
        <el-table-column
          label="状态"
          prop="iStatus">
        </el-table-column>
        <el-table-column
          label="备注"
          prop="iStatus">
        </el-table-column>
        <el-table-column
          fixed="right"
          align="right"
          width="200"
          >
          <template slot="header" slot-scope="scope">
            <el-input
              v-model="search"
              size="small"
              placeholder="输入关键字搜索"/>
          </template>
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click="openDialog(scope.$index, scope.row)">出库</el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog title="选择仓库" :visible.sync="dialogTableVisible">
        <el-table
          :data="base"
          highlight-current-row
          @row-click="handleClickBase">
          <el-table-column property="id" label="仓库编码" width="150"></el-table-column>
          <el-table-column property="name" label="名称" width="200"></el-table-column>
          <el-table-column property="address" label="地址"></el-table-column>
        </el-table>
        <el-button type="primary" @click="handleOut">确定</el-button>
      </el-dialog>
    </div>
</template>

<script>
export default {
  name: "SellDetail-content",
  data() {
    return {
      tableData: [this.oneData],
      oneData:{
        iNo: '',
        cCid: '',
        dtDt: '',
        cClerk: '',
        cCheck: '',
        cCheckout: '',
        dtCheckout: '',
        cInvalid: '',
        dtInvalid: '',
        cComment: '',
        iBono: '',
        iStatus: '',
        detailList: [this.oneDetail]
      },
      oneDetail:{
        iNo: '',
        cGid: '',
        fQuant: '',
        cBunit: '',
        fPrice: '',
        fAmount: '',
        cComment: '',
        dtDt: '',
        goods:{
          cDesc:''
        }
      },
      search: '',
      cCid:'',
      dialogTableVisible:false,
      base:[
        {
          id:'',
          name:'',
          address:''
        }
      ],
      oneBase:'',
      outOneData:'',
      outMaxNo:''
    }
  },
  created(){
    this.initData()
  },
  methods: {
    openDialog(index, row) {
      this.oneData=row;
      this.findBaseAll();
      this.dialogTableVisible = true;
    },
    findBaseAll(){
      this.axios.get("/api/BaseAll").then((res)=>{
        this.base=res.data.data
      })
    },
    handleOut(){
      this.dialogTableVisible = false
      console.log("outBase",this.oneBase)
      let baseId=this.oneBase.id
      console.log("outOneData",baseId)
      let baseOut=this.oneData;
      this.axios({
        method: "POST",
        url: '/api/BaseOut',
        data:baseOut,
        params:{
          baseId:baseId
        },
        headers: {
          'Content-Type': 'application/json;charset=UTF-8',  //指定消息格式
        },
      }).then(function (response) {
        console.log(response);
      }).catch(function (error) {
        console.log(error);
      });
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    handleClickBase(row, event, column) {
      this.oneBase=row;
    },
    initData(){
      this.axios.get("/api/sale/order?pageNum=1&pageSize=8").then((res)=>{
        this.tableData=res.data.data.list;
      }).catch(function(res){
      });

    }
  }
}
</script>

<style scoped>
  .bodyRight{
    height:100%;
    width: 83.3%;
    background: #F5F5F5;
    font-size: 0.9em;
    float: left;
  }
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
</style>
